# mail_fetcher_llm
correlation between stockx mail and shopifymail to sent update to customer automaticaly using llm and pyhton
