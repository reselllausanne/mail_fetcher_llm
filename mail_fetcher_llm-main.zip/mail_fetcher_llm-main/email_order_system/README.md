# Email Order System

A comprehensive system for extracting order information from emails (Shopify, StockX) and integrating with e-commerce platforms.

## Overview

The Email Order System automatically processes order confirmation emails from platforms like Shopify and StockX, extracts relevant order information using a hybrid of rule-based and AI approaches, and provides an API for accessing this data.

### Key Features

- **Email Integration**: Connects to Gmail to fetch and process order confirmation emails.
- **Intelligent Extraction**: Uses a hybrid extraction system that combines rule-based parsing with AI-powered extraction.
- **Size Conversion**: Automatically converts shoe sizes across different measurement systems.
- **Shopify Integration**: Connects with Shopify GraphQL API to fetch and sync order data.
- **RESTful API**: Provides a comprehensive API for accessing and managing emails and orders.
- **Authentication**: Secure JWT-based authentication for API access.
- **Containerization**: Includes Docker and Docker Compose configuration for easy deployment.

## Installation

### Prerequisites

- Python 3.10+
- PostgreSQL database
- Gmail API credentials
- Shopify API credentials (for Shopify integration)
- Ollama (for AI-based extraction)

### Using Docker (Recommended)

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/email-order-system.git
   cd email-order-system
   ```

2. Create a `.env` file based on the provided `.env.example`:
   ```bash
   cp .env.example .env
   ```

3. Update the `.env` file with your credentials:
   - Database connection string
   - Gmail API credentials
   - Shopify API credentials
   - JWT secret key
   - Ollama configuration

4. Start the application using Docker Compose:
   ```bash
   docker-compose up -d
   ```

5. The API will be available at `http://localhost:8000`

### Manual Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/email-order-system.git
   cd email-order-system
   ```

2. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install the requirements:
   ```bash
   pip install -r requirements.txt
   ```

4. Create a `.env` file based on the provided `.env.example` and update it with your credentials.

5. Initialize the database:
   ```bash
   python cli.py init-db
   ```

6. Start the API server:
   ```bash
   python cli.py server
   ```

## Usage

### Command Line Interface

The system includes a CLI for common operations:

```bash
# Start the API server
python cli.py server

# Fetch emails from Gmail
python cli.py fetch --days 7 --limit 50

# Process a specific email by ID
python cli.py process <email_id>

# Sync orders from Shopify
python cli.py sync --limit 10

# Initialize the database
python cli.py init-db
```

### API Usage

See the [API Usage Guide](docs/api_usage_guide.md) for detailed instructions on using the API endpoints.

### Example Python Client

An example API client is included in the `examples` directory:

```bash
# Fetch emails
python examples/api_client.py --username admin --password admin123 fetch --days 7 --limit 10

# List processed emails
python examples/api_client.py list-emails

# Process a specific email
python examples/api_client.py process <email_id>

# List extracted orders
python examples/api_client.py list-orders
```

## Architecture

The system consists of several key components:

1. **Email Processing**:
   - `GmailClient`: Fetches emails from Gmail using the Gmail API.
   - `EmailDecoder`: Decodes email content, handling different formats.

2. **Extraction Engine**:
   - `RuleBasedExtractor`: Uses regex and rules to extract order information.
   - `AIExtractor`: Uses Ollama for AI-powered extraction.
   - `HybridExtractor`: Combines both approaches for optimal results.

3. **Size Conversion**:
   - `SizeConverter`: Converts shoe sizes between different measurement systems.

4. **API**:
   - `FastAPI` framework for the REST API.
   - JWT authentication for secure access.
   - Endpoints for emails, orders, and Shopify integration.

5. **Database**:
   - SQLAlchemy ORM for database interactions.
   - Models for emails, orders, products, and more.

6. **Shopify Integration**:
   - `ShopifyGraphQLClient`: Interacts with Shopify GraphQL API.

## API Endpoints

### Authentication

- `POST /auth/token`: Get an access token

### Emails

- `GET /api/emails`: List processed emails
- `POST /api/emails/fetch`: Fetch emails from Gmail
- `GET /api/emails/{email_id}`: Get a specific email
- `POST /api/emails/{email_id}/process`: Process a specific email

### Orders

- `GET /api/orders`: List extracted orders
- `GET /api/orders/{order_id}`: Get a specific order
- `GET /api/orders/{order_id}/products`: List products in an order

### Shopify

- `GET /api/shopify/orders`: List Shopify orders
- `POST /api/shopify/orders/sync`: Sync orders from Shopify

## Testing

Run the tests using pytest:

```bash
pytest
```

Tests are available for:
- Email extraction
- Size conversion
- API endpoints

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgements

- Gmail API for email integration
- Shopify GraphQL API for e-commerce integration
- Ollama for AI-powered extraction 