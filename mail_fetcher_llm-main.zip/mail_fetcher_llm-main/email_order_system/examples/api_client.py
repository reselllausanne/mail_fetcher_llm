#!/usr/bin/env python
"""
Example API client for the Email Order System.
This script demonstrates authentication, fetching and processing emails.
"""

import requests
import json
import argparse
import logging
from datetime import datetime, timedelta
import sys

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

class EmailOrderApiClient:
    """Client for interacting with the Email Order System API."""
    
    def __init__(self, base_url="http://localhost:8000"):
        """Initialize the client with the API base URL."""
        self.base_url = base_url
        self.token = None
        self.headers = {
            "Content-Type": "application/json"
        }
    
    def authenticate(self, username, password):
        """Authenticate with the API and get an access token."""
        logger.info(f"Authenticating as {username}")
        
        auth_data = {
            "username": username,
            "password": password
        }
        
        try:
            response = requests.post(
                f"{self.base_url}/auth/token",
                data=auth_data,
                headers={"Content-Type": "application/x-www-form-urlencoded"}
            )
            
            response.raise_for_status()
            token_data = response.json()
            self.token = token_data["access_token"]
            self.headers["Authorization"] = f"Bearer {self.token}"
            
            logger.info("Authentication successful")
            return True
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Authentication failed: {str(e)}")
            if hasattr(e, 'response') and e.response:
                logger.error(f"Response: {e.response.text}")
            return False
    
    def fetch_emails(self, days=7, limit=10, query="subject:StockX OR subject:Shopify"):
        """Fetch emails from Gmail through the API."""
        if not self.token:
            logger.error("Not authenticated. Call authenticate() first.")
            return None
        
        logger.info(f"Fetching emails from the last {days} days (limit: {limit})")
        
        fetch_data = {
            "days": days,
            "limit": limit,
            "query": query
        }
        
        try:
            response = requests.post(
                f"{self.base_url}/api/emails/fetch",
                headers=self.headers,
                json=fetch_data
            )
            
            response.raise_for_status()
            result = response.json()
            
            logger.info(f"Successfully fetched {len(result['emails'])} emails")
            return result
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to fetch emails: {str(e)}")
            if hasattr(e, 'response') and e.response:
                logger.error(f"Response: {e.response.text}")
            return None
    
    def list_emails(self, page=1, limit=10):
        """List processed emails from the database."""
        if not self.token:
            logger.error("Not authenticated. Call authenticate() first.")
            return None
        
        logger.info(f"Listing processed emails (page: {page}, limit: {limit})")
        
        try:
            response = requests.get(
                f"{self.base_url}/api/emails?page={page}&limit={limit}",
                headers=self.headers
            )
            
            response.raise_for_status()
            result = response.json()
            
            logger.info(f"Retrieved {len(result['items'])} emails")
            return result
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to list emails: {str(e)}")
            if hasattr(e, 'response') and e.response:
                logger.error(f"Response: {e.response.text}")
            return None
    
    def get_email(self, email_id):
        """Get a specific email by ID."""
        if not self.token:
            logger.error("Not authenticated. Call authenticate() first.")
            return None
        
        logger.info(f"Getting email with ID: {email_id}")
        
        try:
            response = requests.get(
                f"{self.base_url}/api/emails/{email_id}",
                headers=self.headers
            )
            
            response.raise_for_status()
            result = response.json()
            
            logger.info(f"Retrieved email: {result['subject']}")
            return result
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to get email: {str(e)}")
            if hasattr(e, 'response') and e.response:
                logger.error(f"Response: {e.response.text}")
            return None
    
    def process_email(self, email_id):
        """Process a specific email to extract order information."""
        if not self.token:
            logger.error("Not authenticated. Call authenticate() first.")
            return None
        
        logger.info(f"Processing email with ID: {email_id}")
        
        try:
            response = requests.post(
                f"{self.base_url}/api/emails/{email_id}/process",
                headers=self.headers
            )
            
            response.raise_for_status()
            result = response.json()
            
            logger.info(f"Email processed successfully: {result['message']}")
            return result
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to process email: {str(e)}")
            if hasattr(e, 'response') and e.response:
                logger.error(f"Response: {e.response.text}")
            return None
    
    def list_orders(self, page=1, limit=10):
        """List extracted orders from the database."""
        if not self.token:
            logger.error("Not authenticated. Call authenticate() first.")
            return None
        
        logger.info(f"Listing orders (page: {page}, limit: {limit})")
        
        try:
            response = requests.get(
                f"{self.base_url}/api/orders?page={page}&limit={limit}",
                headers=self.headers
            )
            
            response.raise_for_status()
            result = response.json()
            
            logger.info(f"Retrieved {len(result['items'])} orders")
            return result
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to list orders: {str(e)}")
            if hasattr(e, 'response') and e.response:
                logger.error(f"Response: {e.response.text}")
            return None

def main():
    """Main entry point for the example client."""
    parser = argparse.ArgumentParser(description="Email Order System API Client Example")
    
    # Authentication arguments
    parser.add_argument("--username", default="admin", help="API username")
    parser.add_argument("--password", default="admin123", help="API password")
    parser.add_argument("--url", default="http://localhost:8000", help="API base URL")
    
    # Action arguments
    subparsers = parser.add_subparsers(dest="action", help="Action to perform")
    
    # Fetch emails action
    fetch_parser = subparsers.add_parser("fetch", help="Fetch emails from Gmail")
    fetch_parser.add_argument("--days", type=int, default=7, help="Number of days to look back")
    fetch_parser.add_argument("--limit", type=int, default=10, help="Maximum number of emails to fetch")
    fetch_parser.add_argument("--query", default="subject:StockX OR subject:Shopify", 
                              help="Search query for emails")
    
    # List emails action
    list_parser = subparsers.add_parser("list-emails", help="List processed emails")
    list_parser.add_argument("--page", type=int, default=1, help="Page number")
    list_parser.add_argument("--limit", type=int, default=10, help="Items per page")
    
    # Get email action
    get_parser = subparsers.add_parser("get-email", help="Get a specific email")
    get_parser.add_argument("email_id", help="Email ID to retrieve")
    
    # Process email action
    process_parser = subparsers.add_parser("process", help="Process a specific email")
    process_parser.add_argument("email_id", help="Email ID to process")
    
    # List orders action
    orders_parser = subparsers.add_parser("list-orders", help="List extracted orders")
    orders_parser.add_argument("--page", type=int, default=1, help="Page number")
    orders_parser.add_argument("--limit", type=int, default=10, help="Items per page")
    
    # Parse arguments
    args = parser.parse_args()
    
    if not args.action:
        parser.print_help()
        return 1
    
    # Initialize the client
    client = EmailOrderApiClient(base_url=args.url)
    
    # Authenticate
    if not client.authenticate(args.username, args.password):
        logger.error("Authentication failed. Exiting.")
        return 1
    
    # Perform the requested action
    if args.action == "fetch":
        result = client.fetch_emails(days=args.days, limit=args.limit, query=args.query)
        if result:
            print(json.dumps(result, indent=2))
    
    elif args.action == "list-emails":
        result = client.list_emails(page=args.page, limit=args.limit)
        if result:
            print(json.dumps(result, indent=2))
    
    elif args.action == "get-email":
        result = client.get_email(args.email_id)
        if result:
            print(json.dumps(result, indent=2))
    
    elif args.action == "process":
        result = client.process_email(args.email_id)
        if result:
            print(json.dumps(result, indent=2))
    
    elif args.action == "list-orders":
        result = client.list_orders(page=args.page, limit=args.limit)
        if result:
            print(json.dumps(result, indent=2))
    
    return 0

if __name__ == "__main__":
    sys.exit(main()) 