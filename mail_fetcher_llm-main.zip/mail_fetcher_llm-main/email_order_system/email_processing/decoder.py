import base64
import quopri
import html
import urllib.parse
import chardet
import logging
from bs4 import BeautifulSoup
import re
from typing import Optional, Dict, Any

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class EmailDecoder:
    """Deep email decoder that handles various encoding formats."""
    
    @staticmethod
    def deep_decode(encoded_text: str) -> str:
        """
        Recursively decode an email body through various potential encoding layers.
        
        Args:
            encoded_text: The raw potentially encoded email text
            
        Returns:
            Decoded text with all encoding layers removed
        """
        if not encoded_text:
            return ""
        
        # Keep track of previous decoded text to detect when no changes are made
        prev_text = None
        current_text = encoded_text
        
        # Limit iterations to prevent infinite loops
        max_iterations = 10
        iterations = 0
        
        # Continue decoding until no more changes are detected or max iterations reached
        while prev_text != current_text and iterations < max_iterations:
            prev_text = current_text
            
            # Try different decoding methods
            current_text = EmailDecoder._try_base64_decode(current_text)
            current_text = EmailDecoder._try_quoted_printable_decode(current_text)
            current_text = EmailDecoder._try_html_entity_decode(current_text)
            current_text = EmailDecoder._try_url_decode(current_text)
            
            iterations += 1
        
        # Detect charset and decode if needed
        current_text = EmailDecoder._decode_with_charset_detection(current_text)
        
        return current_text
    
    @staticmethod
    def _try_base64_decode(text: str) -> str:
        """
        Try to decode base64 encoded text.
        
        Args:
            text: Potentially base64 encoded text
            
        Returns:
            Decoded text if successful, original text otherwise
        """
        # Only attempt base64 decoding if the text looks like base64
        if not EmailDecoder._looks_like_base64(text):
            return text
        
        try:
            # Add padding if needed
            padded_text = text
            padding_needed = len(text) % 4
            if padding_needed:
                padded_text += "=" * (4 - padding_needed)
            
            # Try standard base64 first
            decoded = base64.b64decode(padded_text).decode('utf-8', errors='replace')
            return decoded
        except Exception:
            try:
                # Try URL-safe base64
                decoded = base64.urlsafe_b64decode(padded_text).decode('utf-8', errors='replace')
                return decoded
            except Exception:
                # Return original text if decoding fails
                return text
    
    @staticmethod
    def _looks_like_base64(text: str) -> bool:
        """
        Check if text looks like it might be base64 encoded.
        
        Args:
            text: Text to check
            
        Returns:
            True if text might be base64 encoded, False otherwise
        """
        # Base64 alphabet check
        if not re.match(r'^[A-Za-z0-9+/=]+$', text):
            return False
        
        # Length check - base64 encoded text should be a multiple of 4
        # But we account for possible truncation
        if len(text) < 8:  # Too short to be meaningful base64
            return False
        
        # Avoid decoding text that's clearly not base64
        if re.search(r'[a-zA-Z]{20,}', text):  # Long alphabetic sequences
            return False
        
        return True
    
    @staticmethod
    def _try_quoted_printable_decode(text: str) -> str:
        """
        Try to decode quoted-printable encoded text.
        
        Args:
            text: Potentially quoted-printable encoded text
            
        Returns:
            Decoded text if successful, original text otherwise
        """
        if not '=' in text:
            return text
        
        try:
            return quopri.decodestring(text).decode('utf-8', errors='replace')
        except Exception:
            return text
    
    @staticmethod
    def _try_html_entity_decode(text: str) -> str:
        """
        Decode HTML entities in text.
        
        Args:
            text: Text with potential HTML entities
            
        Returns:
            Text with HTML entities decoded
        """
        if not ('&' in text and ';' in text):
            return text
        
        try:
            return html.unescape(text)
        except Exception:
            return text
    
    @staticmethod
    def _try_url_decode(text: str) -> str:
        """
        Decode URL/percent encoded text.
        
        Args:
            text: Potentially URL encoded text
            
        Returns:
            Decoded text if successful, original text otherwise
        """
        if not '%' in text:
            return text
        
        try:
            return urllib.parse.unquote(text)
        except Exception:
            return text
    
    @staticmethod
    def _decode_with_charset_detection(text: str) -> str:
        """
        Detect charset and decode accordingly.
        
        Args:
            text: Text to decode with potential charset issues
            
        Returns:
            Text decoded with detected charset
        """
        if isinstance(text, bytes):
            # Detect encoding
            result = chardet.detect(text)
            encoding = result['encoding'] or 'utf-8'
            confidence = result['confidence']
            
            logger.debug(f"Detected encoding: {encoding} with confidence: {confidence}")
            
            try:
                return text.decode(encoding, errors='replace')
            except Exception:
                return text.decode('utf-8', errors='replace')
        return text
    
    @staticmethod
    def html_to_text(html_content: str) -> str:
        """
        Convert HTML content to plain text.
        
        Args:
            html_content: HTML content to convert
            
        Returns:
            Plain text extracted from HTML
        """
        if not html_content:
            return ""
        
        try:
            # Parse HTML with BeautifulSoup
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # Remove script and style elements
            for script_or_style in soup(["script", "style"]):
                script_or_style.extract()
            
            # Get text
            text = soup.get_text()
            
            # Break into lines and remove leading and trailing space on each
            lines = (line.strip() for line in text.splitlines())
            
            # Break multi-headlines into a line each
            chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
            
            # Remove blank lines
            text = '\n'.join(chunk for chunk in chunks if chunk)
            
            return text
        except Exception as e:
            logger.error(f"Error converting HTML to text: {str(e)}")
            return html_content
    
    @staticmethod
    def process_email(email_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process an email by decoding its content and converting to plain text.
        
        Args:
            email_data: Dictionary containing email data including 'raw_content'
            
        Returns:
            Updated email data with 'decoded_content' and 'plain_text' fields
        """
        if not email_data or 'raw_content' not in email_data:
            return email_data
        
        # Make a copy to avoid modifying the original
        processed_data = email_data.copy()
        
        # Decode the raw content
        decoded_content = EmailDecoder.deep_decode(email_data['raw_content'])
        processed_data['decoded_content'] = decoded_content
        
        # Convert HTML to plain text
        plain_text = EmailDecoder.html_to_text(decoded_content)
        processed_data['plain_text'] = plain_text
        
        return processed_data 