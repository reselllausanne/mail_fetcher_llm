import re
import logging
from typing import Dict, Optional, Tuple

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SizeConverter:
    """
    Utility for normalizing and converting shoe sizes across different formats.
    """
    
    def __init__(self):
        """Initialize the size converter with conversion tables."""
        # Men's US to EU size conversion
        self.mens_us_to_eu = {
            "6": "39",
            "6.5": "39.5",
            "7": "40",
            "7.5": "40.5",
            "8": "41",
            "8.5": "42",
            "9": "42.5",
            "9.5": "43",
            "10": "44",
            "10.5": "44.5",
            "11": "45",
            "11.5": "45.5",
            "12": "46",
            "12.5": "46.5",
            "13": "47",
            "13.5": "47.5",
            "14": "48",
            "14.5": "48.5",
            "15": "49"
        }
        
        # Women's US to EU size conversion
        self.womens_us_to_eu = {
            "5": "35.5",
            "5.5": "36",
            "6": "36.5",
            "6.5": "37",
            "7": "37.5",
            "7.5": "38",
            "8": "38.5",
            "8.5": "39",
            "9": "40",
            "9.5": "40.5",
            "10": "41",
            "10.5": "41.5",
            "11": "42",
            "11.5": "42.5",
            "12": "43"
        }
        
        # Brand-specific adjustments
        self.brand_adjustments = {
            "nike": {"offset": 0},  # No adjustment for Nike
            "jordan": {"offset": 0},  # Jordan follows Nike sizing
            "adidas": {"offset": 0.5},  # Adidas runs about 0.5 size larger
            "yeezy": {"offset": 0.5},  # Yeezy follows Adidas sizing
            "new balance": {"offset": 0.5},  # New Balance runs about 0.5 size larger
            "converse": {"offset": -1},  # Converse runs about 1 size smaller
            "vans": {"offset": -0.5}  # Vans runs about 0.5 size smaller
        }
    
    def normalize_size(self, size_str: str, product_name: Optional[str] = None) -> Dict[str, str]:
        """
        Normalize a size string to US and EU formats.
        
        Args:
            size_str: The original size string from the email
            product_name: Optional product name for brand detection
            
        Returns:
            Dictionary with normalized size information
        """
        size_info = {
            "original": size_str,
            "us": None,
            "eu": None,
            "gender": None,
            "brand": None,
            "confidence": 0.0
        }
        
        if not size_str:
            return size_info
        
        # Clean up the size string
        cleaned_size = size_str.strip().upper()
        
        # Extract the numeric part and the gender
        size_value, gender = self._extract_size_and_gender(cleaned_size)
        if not size_value:
            return size_info
        
        # Detect brand from product name
        brand = self._detect_brand(product_name) if product_name else None
        
        # Set the normalized US size format
        us_size = f"US {size_value}"
        if gender:
            us_size = f"{us_size} {gender[0]}"  # M or W
        
        # Convert to EU size
        eu_size = self._convert_to_eu(size_value, gender, brand)
        
        # Calculate confidence
        confidence = self._calculate_confidence(size_value, gender, brand, product_name)
        
        # Update the size info
        size_info["us"] = us_size
        size_info["eu"] = eu_size
        size_info["gender"] = gender
        size_info["brand"] = brand
        size_info["confidence"] = confidence
        
        return size_info
    
    def _extract_size_and_gender(self, size_str: str) -> Tuple[Optional[str], Optional[str]]:
        """
        Extract the numeric size value and gender from a size string.
        
        Args:
            size_str: The size string to parse
            
        Returns:
            Tuple of (size_value, gender)
        """
        # Common patterns to match
        us_with_gender = re.search(r'US\s*(\d+(?:\.\d+)?)\s*([MW])', size_str)
        us_without_gender = re.search(r'US\s*(\d+(?:\.\d+)?)', size_str)
        just_size_with_gender = re.search(r'(\d+(?:\.\d+)?)\s*([MW])', size_str)
        just_size = re.search(r'(\d+(?:\.\d+)?)', size_str)
        
        size_value = None
        gender = None
        
        if us_with_gender:
            size_value = us_with_gender.group(1)
            gender = "Men" if us_with_gender.group(2) == "M" else "Women"
        elif us_without_gender:
            size_value = us_without_gender.group(1)
            # Default to Men if no gender specified
            gender = "Men"
        elif just_size_with_gender:
            size_value = just_size_with_gender.group(1)
            gender = "Men" if just_size_with_gender.group(2) == "M" else "Women"
        elif just_size:
            size_value = just_size.group(1)
            # Default to Men if no gender specified
            gender = "Men"
        
        # Look for explicit gender mentions
        if not gender and ("MEN" in size_str or "MENS" in size_str):
            gender = "Men"
        elif not gender and ("WOMEN" in size_str or "WOMENS" in size_str):
            gender = "Women"
        
        return size_value, gender
    
    def _detect_brand(self, product_name: str) -> Optional[str]:
        """
        Detect the brand from a product name.
        
        Args:
            product_name: The product name
            
        Returns:
            Detected brand or None
        """
        if not product_name:
            return None
        
        product_lower = product_name.lower()
        
        for brand in self.brand_adjustments.keys():
            if brand in product_lower:
                return brand
        
        return None
    
    def _convert_to_eu(self, size_value: str, gender: Optional[str], brand: Optional[str]) -> Optional[str]:
        """
        Convert a US size to EU size.
        
        Args:
            size_value: The US size value
            gender: The gender (Men/Women)
            brand: The detected brand
            
        Returns:
            EU size string or None if conversion fails
        """
        try:
            # Apply brand-specific adjustment if available
            adjusted_size = size_value
            if brand and brand in self.brand_adjustments:
                size_float = float(size_value)
                offset = self.brand_adjustments[brand]["offset"]
                adjusted_size = str(size_float + offset)
                
                # Handle half sizes
                if adjusted_size.endswith(".0"):
                    adjusted_size = adjusted_size[:-2]
                elif adjusted_size.endswith(".5"):
                    pass  # Keep half sizes as is
                else:
                    # Round to nearest half size
                    size_float = float(adjusted_size)
                    rounded = round(size_float * 2) / 2
                    adjusted_size = str(rounded)
                    if adjusted_size.endswith(".0"):
                        adjusted_size = adjusted_size[:-2]
            
            # Look up EU size based on gender
            if gender == "Women":
                if adjusted_size in self.womens_us_to_eu:
                    return f"EU {self.womens_us_to_eu[adjusted_size]}"
            else:  # Default to Men's sizing
                if adjusted_size in self.mens_us_to_eu:
                    return f"EU {self.mens_us_to_eu[adjusted_size]}"
            
            return None
        except Exception as e:
            logger.error(f"Error converting to EU size: {e}")
            return None
    
    def _calculate_confidence(self, size_value: str, gender: Optional[str], 
                             brand: Optional[str], product_name: Optional[str]) -> float:
        """
        Calculate the confidence score for the size normalization.
        
        Args:
            size_value: The extracted size value
            gender: The detected gender
            brand: The detected brand
            product_name: The product name
            
        Returns:
            Confidence score between 0.0 and 1.0
        """
        confidence = 0.7  # Base confidence
        
        # Higher confidence if we have more information
        if gender:
            confidence += 0.1
        
        if brand:
            confidence += 0.1
        
        # Higher confidence if the size value is in our conversion tables
        if gender == "Women" and size_value in self.womens_us_to_eu:
            confidence += 0.1
        elif gender != "Women" and size_value in self.mens_us_to_eu:
            confidence += 0.1
        
        # Cap confidence at 1.0
        return min(confidence, 1.0) 