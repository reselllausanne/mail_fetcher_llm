from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Boolean, Text, JSON, Table
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from sqlalchemy.ext.declarative import declarative_base
import enum
from datetime import datetime
import uuid

from database.session import Base

class Platform(enum.Enum):
    SHOPIFY = "shopify"
    STOCKX = "stockx"

class OrderStatus(enum.Enum):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    SHIPPED = "shipped"
    DELIVERED = "delivered"
    CANCELED = "canceled"
    UNKNOWN = "unknown"

class Order(Base):
    __tablename__ = "orders"

    id = Column(Integer, primary_key=True, index=True)
    platform = Column(String, nullable=False)
    order_number = Column(String, unique=True, index=True, nullable=False)
    order_date = Column(DateTime, nullable=True)
    customer_email = Column(String, index=True)
    status = Column(String, default=OrderStatus.UNKNOWN.value)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    # Relationships
    products = relationship("Product", back_populates="order")
    email_logs = relationship("EmailLog", back_populates="order")
    
    # For potential linked orders
    shopify_linked_order_id = Column(Integer, ForeignKey("orders.id"), nullable=True)
    stockx_linked_order_id = Column(Integer, ForeignKey("orders.id"), nullable=True)
    
    # For rule-based and LLM extraction tracing
    extraction_metadata = Column(JSON, nullable=True)
    extraction_confidence = Column(Float, nullable=True)

class Product(Base):
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("orders.id"), nullable=False)
    product_name = Column(String, nullable=False)
    brand = Column(String, nullable=True)
    model = Column(String, nullable=True)
    size_original = Column(String, nullable=True)  # As extracted from email
    size_us = Column(String, nullable=True)       # Normalized to US format
    size_eu = Column(String, nullable=True)       # Converted to EU format
    price = Column(Float, nullable=True)
    currency = Column(String, default="USD")
    tracking_number = Column(String, nullable=True, index=True)
    carrier = Column(String, nullable=True)
    
    # Relationship
    order = relationship("Order", back_populates="products")

class EmailLog(Base):
    __tablename__ = "email_logs"

    id = Column(Integer, primary_key=True, index=True)
    email_id = Column(String, unique=True, index=True, nullable=False)  # Gmail ID
    subject = Column(String, nullable=True)
    sender = Column(String, nullable=True)
    recipient = Column(String, nullable=True)
    received_date = Column(DateTime, nullable=True)
    processed_date = Column(DateTime, default=func.now())
    raw_content = Column(Text, nullable=True)
    decoded_content = Column(Text, nullable=True)
    order_id = Column(Integer, ForeignKey("orders.id"), nullable=True)
    processing_status = Column(String, default="pending")
    processing_errors = Column(JSON, nullable=True)
    
    # Relationship
    order = relationship("Order", back_populates="email_logs")

class ExtractionFailure(Base):
    __tablename__ = "extraction_failures"

    id = Column(Integer, primary_key=True, index=True)
    email_log_id = Column(Integer, ForeignKey("email_logs.id"), nullable=False)
    failure_type = Column(String, nullable=False)  # e.g., "regex_failed", "llm_failed"
    field_name = Column(String, nullable=True)    # Which field failed extraction
    attempted_value = Column(String, nullable=True)
    error_message = Column(String, nullable=True)
    created_at = Column(DateTime, default=func.now())
    
    # Additional metadata for debugging
    retry_count = Column(Integer, default=0)
    resolved = Column(Boolean, default=False)
    resolution_method = Column(String, nullable=True)

class LLMPromptCache(Base):
    __tablename__ = "llm_prompt_cache"

    id = Column(Integer, primary_key=True, index=True)
    email_hash = Column(String, unique=True, index=True)  # MD5 of email content for caching
    prompt = Column(Text, nullable=False)
    response = Column(JSON, nullable=False)
    created_at = Column(DateTime, default=func.now())
    confidence_score = Column(Float, nullable=True)
    token_count = Column(Integer, nullable=True)
    platform_detected = Column(String, nullable=True) 