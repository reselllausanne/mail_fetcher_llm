#!/usr/bin/env python
import argparse
import logging
import sys
import os
import uvicorn
import asyncio
from datetime import datetime

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

def setup_parser():
    """Set up the argument parser."""
    parser = argparse.ArgumentParser(description="Email Order Extraction & Linking System")
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Server command
    server_parser = subparsers.add_parser("server", help="Run the FastAPI server")
    server_parser.add_argument("--host", type=str, default="0.0.0.0", help="Host to bind to")
    server_parser.add_argument("--port", type=int, default=8000, help="Port to bind to")
    server_parser.add_argument("--reload", action="store_true", help="Enable auto-reload for development")
    
    # Fetch command
    fetch_parser = subparsers.add_parser("fetch", help="Fetch emails")
    fetch_parser.add_argument("--days", type=int, default=7, help="Number of days to look back")
    fetch_parser.add_argument("--limit", type=int, default=50, help="Maximum number of emails to fetch")
    
    # Process command
    process_parser = subparsers.add_parser("process", help="Process an email by ID")
    process_parser.add_argument("email_id", type=str, help="Email ID to process")
    
    # Sync command
    sync_parser = subparsers.add_parser("sync", help="Sync orders from Shopify")
    sync_parser.add_argument("--limit", type=int, default=10, help="Maximum number of orders to fetch")
    
    # Init database command
    init_db_parser = subparsers.add_parser("init-db", help="Initialize the database")
    
    return parser

async def fetch_emails(days, limit):
    """Fetch emails from Gmail."""
    from email_processing.gmail_client import GmailClient
    from email_processing.decoder import EmailDecoder
    from extractors.hybrid_extractor import HybridExtractor
    from database.session import SessionLocal
    
    logger.info(f"Fetching emails from the last {days} days (limit: {limit})...")
    
    try:
        # Initialize clients
        gmail_client = GmailClient()
        
        # Fetch emails
        emails = gmail_client.fetch_emails_by_date_range(
            query='subject:StockX OR subject:Shopify',
            days=days,
            max_results=limit
        )
        
        logger.info(f"Fetched {len(emails)} emails")
        
        # Process emails
        for email_data in emails:
            logger.info(f"Processing email: {email_data['subject']}")
            # Here you would typically store and process the email
            # For CLI mode, just log the information
            logger.info(f"Email ID: {email_data['email_id']}")
            logger.info(f"Subject: {email_data['subject']}")
            logger.info(f"Sender: {email_data['sender']}")
            logger.info(f"Date: {email_data['received_date']}")
            logger.info("-----")
        
        return True
        
    except Exception as e:
        logger.error(f"Error fetching emails: {e}")
        return False

async def process_email(email_id):
    """Process a specific email by ID."""
    logger.info(f"Processing email ID: {email_id}")
    # Implementation would use the database to find and process the email
    
    return True

async def sync_shopify(limit):
    """Sync orders from Shopify."""
    from shopify.graphql_client import ShopifyGraphQLClient
    
    logger.info(f"Syncing up to {limit} orders from Shopify...")
    
    try:
        # Initialize client
        shopify_client = ShopifyGraphQLClient()
        
        # Fetch orders
        orders = await shopify_client.fetch_orders(limit)
        
        logger.info(f"Fetched {len(orders)} orders from Shopify")
        
        # Log order details
        for order in orders:
            logger.info(f"Order: {order.get('order_number')}")
            logger.info(f"Date: {order.get('order_date')}")
            logger.info(f"Customer: {order.get('customer_email')}")
            logger.info(f"Product: {order.get('product_name')}")
            logger.info("-----")
        
        return True
        
    except Exception as e:
        logger.error(f"Error syncing Shopify orders: {e}")
        return False

def init_database():
    """Initialize the database with alembic."""
    import subprocess
    
    logger.info("Initializing database...")
    
    try:
        # Run alembic upgrade
        current_dir = os.path.dirname(os.path.abspath(__file__))
        alembic_dir = os.path.join(current_dir, "database")
        
        result = subprocess.run(
            ["alembic", "upgrade", "head"], 
            cwd=alembic_dir,
            check=True,
            capture_output=True,
            text=True
        )
        
        logger.info("Database initialization complete")
        logger.info(result.stdout)
        
        return True
        
    except subprocess.CalledProcessError as e:
        logger.error(f"Error initializing database: {e}")
        logger.error(e.stdout)
        logger.error(e.stderr)
        return False
    
    except Exception as e:
        logger.error(f"Error initializing database: {e}")
        return False

def run_server(host, port, reload):
    """Run the FastAPI server."""
    logger.info(f"Starting server on {host}:{port}...")
    
    uvicorn.run(
        "api.main:app",
        host=host,
        port=port,
        reload=reload
    )

def main():
    """Main entry point for the CLI."""
    parser = setup_parser()
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    if args.command == "server":
        run_server(args.host, args.port, args.reload)
    elif args.command == "fetch":
        asyncio.run(fetch_emails(args.days, args.limit))
    elif args.command == "process":
        asyncio.run(process_email(args.email_id))
    elif args.command == "sync":
        asyncio.run(sync_shopify(args.limit))
    elif args.command == "init-db":
        init_database()
    else:
        parser.print_help()
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main()) 