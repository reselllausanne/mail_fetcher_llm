import os
import logging
import json
from typing import Dict, Any, Optional
import httpx
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ShopifyGraphQLClient:
    """Client for interacting with Shopify Admin GraphQL API."""
    
    def __init__(self):
        """Initialize the Shopify GraphQL client."""
        self.store_url = os.getenv("SHOPIFY_STORE_URL")
        self.access_token = os.getenv("SHOPIFY_ACCESS_TOKEN")
        
        if not self.store_url or not self.access_token:
            logger.error("Shopify API credentials not properly configured")
            raise ValueError("Missing Shopify API credentials in environment variables")
        
        # Ensure the store URL has the correct format
        if not self.store_url.startswith("https://"):
            self.store_url = f"https://{self.store_url}"
        
        # Set up the GraphQL endpoint
        self.graphql_url = f"{self.store_url}/admin/api/2023-04/graphql.json"
        
        logger.info(f"Initialized Shopify GraphQL client for store: {self.store_url}")
    
    async def fetch_order_customer_email(self, order_number: str) -> Optional[str]:
        """
        Fetch customer email for a specific order number.
        
        Args:
            order_number: The Shopify order number (e.g., "#1001")
            
        Returns:
            Customer email or None if not found
        """
        # Ensure order number has the correct format
        if not order_number.startswith("#"):
            order_number = f"#{order_number}"
        
        # Build the GraphQL query
        query = """
        query {
            orders(first: 1, query: "name:%s") {
                edges {
                    node {
                        name
                        customer {
                            email
                        }
                    }
                }
            }
        }
        """ % order_number
        
        try:
            # Execute the query
            result = await self.execute_query(query)
            
            # Extract the email from the response
            if result and "data" in result and "orders" in result["data"]:
                edges = result["data"]["orders"]["edges"]
                if edges and len(edges) > 0:
                    customer = edges[0]["node"].get("customer")
                    if customer:
                        return customer.get("email")
            
            logger.warning(f"No customer email found for order {order_number}")
            return None
            
        except Exception as e:
            logger.error(f"Error fetching customer email for order {order_number}: {e}")
            return None
    
    async def execute_query(self, query: str) -> Dict[str, Any]:
        """
        Execute a GraphQL query against the Shopify Admin API.
        
        Args:
            query: The GraphQL query to execute
            
        Returns:
            Dictionary with the query results
        """
        try:
            headers = {
                "Content-Type": "application/json",
                "X-Shopify-Access-Token": self.access_token
            }
            
            payload = {
                "query": query
            }
            
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    self.graphql_url,
                    headers=headers,
                    json=payload
                )
                
                response.raise_for_status()
                return response.json()
                
        except httpx.RequestError as e:
            logger.error(f"Request error executing GraphQL query: {e}")
            raise
            
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error {e.response.status_code} executing GraphQL query: {e.response.text}")
            raise
            
        except Exception as e:
            logger.error(f"Unexpected error executing GraphQL query: {e}")
            raise
    
    async def fetch_orders(self, limit: int = 10) -> list:
        """
        Fetch recent orders from Shopify.
        
        Args:
            limit: Maximum number of orders to fetch
            
        Returns:
            List of order data
        """
        query = """
        query {
            orders(first: %d, sortKey: CREATED_AT, reverse: true) {
                edges {
                    node {
                        name
                        createdAt
                        customer {
                            email
                        }
                        lineItems(first: 5) {
                            edges {
                                node {
                                    title
                                    variant {
                                        title
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        """ % limit
        
        try:
            result = await self.execute_query(query)
            
            orders = []
            if result and "data" in result and "orders" in result["data"]:
                for edge in result["data"]["orders"]["edges"]:
                    node = edge["node"]
                    
                    # Process line items
                    line_items = []
                    if "lineItems" in node and "edges" in node["lineItems"]:
                        for item_edge in node["lineItems"]["edges"]:
                            item_node = item_edge["node"]
                            line_items.append({
                                "title": item_node.get("title"),
                                "variant": item_node.get("variant", {}).get("title")
                            })
                    
                    # Extract customer email
                    customer_email = None
                    if "customer" in node and node["customer"]:
                        customer_email = node["customer"].get("email")
                    
                    # Create order object
                    order = {
                        "platform": "shopify",
                        "order_number": node.get("name"),
                        "order_date": node.get("createdAt"),
                        "customer_email": customer_email,
                        "product_name": line_items[0]["title"] if line_items else None,
                        "product_size": line_items[0]["variant"] if line_items else None
                    }
                    
                    orders.append(order)
            
            return orders
            
        except Exception as e:
            logger.error(f"Error fetching orders: {e}")
            return [] 