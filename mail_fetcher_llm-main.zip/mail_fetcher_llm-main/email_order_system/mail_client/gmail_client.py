import os
import base64
import json
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from dotenv import load_dotenv

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Gmail API scopes
SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']

class GmailClient:
    """Client for interacting with Gmail API to fetch emails."""
    
    def __init__(self):
        """Initialize the Gmail client with credentials."""
        self.credentials = None
        self.service = None
        self._setup_credentials()
    
    def _setup_credentials(self):
        """Set up the OAuth credentials for Gmail API."""
        client_id = os.getenv("GMAIL_CLIENT_ID")
        client_secret = os.getenv("GMAIL_CLIENT_SECRET")
        refresh_token = os.getenv("GMAIL_REFRESH_TOKEN")
        
        if not all([client_id, client_secret, refresh_token]):
            logger.error("Gmail API credentials are not properly configured.")
            raise ValueError("Gmail API credentials are missing in environment variables.")
        
        # Create credentials object from environment variables
        self.credentials = Credentials(
            None,  # No access token initially
            refresh_token=refresh_token,
            token_uri="https://oauth2.googleapis.com/token",
            client_id=client_id,
            client_secret=client_secret,
            scopes=SCOPES
        )
        
        # Refresh the access token if expired
        if self.credentials.expired:
            self.credentials.refresh(Request())
        
        # Build the Gmail service
        self.service = build('gmail', 'v1', credentials=self.credentials)
        logger.info("Gmail API client initialized successfully.")
    
    def fetch_emails(self, query: str = 'subject:StockX OR subject:Shopify', max_results: int = 10) -> List[Dict[str, Any]]:
        """
        Fetch emails from Gmail based on a search query.
        
        Args:
            query: Gmail search query (default: subject:StockX OR subject:Shopify)
            max_results: Maximum number of emails to fetch (default: 10)
            
        Returns:
            List of email dictionaries with id, subject, sender, date, and raw content
        """
        try:
            # Get list of message IDs matching the query
            results = self.service.users().messages().list(
                userId='me',
                q=query,
                maxResults=max_results
            ).execute()
            
            messages = results.get('messages', [])
            
            if not messages:
                logger.info(f"No emails found matching query: {query}")
                return []
            
            # Fetch full email details for each message ID
            emails = []
            for message in messages:
                email_data = self._get_email_data(message['id'])
                if email_data:
                    emails.append(email_data)
            
            logger.info(f"Successfully fetched {len(emails)} emails.")
            return emails
            
        except Exception as e:
            logger.error(f"Error fetching emails: {str(e)}")
            raise
    
    def _get_email_data(self, msg_id: str) -> Optional[Dict[str, Any]]:
        """
        Get detailed data for a specific email by ID.
        
        Args:
            msg_id: The Gmail message ID
            
        Returns:
            Dictionary with email details or None if error
        """
        try:
            # Get the full message details
            message = self.service.users().messages().get(
                userId='me',
                id=msg_id,
                format='full'
            ).execute()
            
            # Extract headers
            headers = message['payload']['headers']
            subject = next((h['value'] for h in headers if h['name'].lower() == 'subject'), 'No Subject')
            sender = next((h['value'] for h in headers if h['name'].lower() == 'from'), 'Unknown')
            date_str = next((h['value'] for h in headers if h['name'].lower() == 'date'), None)
            
            # Parse RFC 2822 date to datetime
            received_date = None
            if date_str:
                try:
                    # This is simplified - a proper implementation would need more robust date parsing
                    from email.utils import parsedate_to_datetime
                    received_date = parsedate_to_datetime(date_str)
                except Exception as e:
                    logger.warning(f"Could not parse email date: {e}")
            
            # Get the email body
            raw_content = self._get_email_body(message)
            
            # Construct the email data dictionary
            email_data = {
                'email_id': msg_id,
                'subject': subject,
                'sender': sender,
                'received_date': received_date.isoformat() if received_date else None,
                'raw_content': raw_content,
                'labels': message.get('labelIds', []),
                'snippet': message.get('snippet', '')
            }
            
            return email_data
            
        except Exception as e:
            logger.error(f"Error getting email data for ID {msg_id}: {str(e)}")
            return None
    
    def _get_email_body(self, message: Dict[str, Any]) -> str:
        """
        Extract the email body from a Gmail message.
        
        Args:
            message: The Gmail message object
            
        Returns:
            String containing the email body
        """
        try:
            parts = []
            
            if 'parts' in message['payload']:
                for part in message['payload']['parts']:
                    if part.get('mimeType') == 'text/plain' or part.get('mimeType') == 'text/html':
                        if 'data' in part['body']:
                            data = part['body']['data']
                            text = base64.urlsafe_b64decode(data).decode('utf-8', errors='replace')
                            parts.append(text)
                    elif 'parts' in part:
                        # Handle nested multipart messages
                        for nested_part in part['parts']:
                            if nested_part.get('mimeType') == 'text/plain' or nested_part.get('mimeType') == 'text/html':
                                if 'data' in nested_part['body']:
                                    data = nested_part['body']['data']
                                    text = base64.urlsafe_b64decode(data).decode('utf-8', errors='replace')
                                    parts.append(text)
            elif 'body' in message['payload'] and 'data' in message['payload']['body']:
                # Single part message
                data = message['payload']['body']['data']
                text = base64.urlsafe_b64decode(data).decode('utf-8', errors='replace')
                parts.append(text)
            
            # Prefer HTML content if available
            html_parts = [p for p in parts if '<html' in p.lower()]
            if html_parts:
                return html_parts[0]
            elif parts:
                return parts[0]
            else:
                return "No content found."
                
        except Exception as e:
            logger.error(f"Error extracting email body: {str(e)}")
            return "Error extracting email content."
    
    def fetch_emails_by_date_range(self, 
                                  query: str = 'subject:StockX OR subject:Shopify',
                                  days: int = 7, 
                                  max_results: int = 50) -> List[Dict[str, Any]]:
        """
        Fetch emails from a specific date range.
        
        Args:
            query: Gmail search query
            days: Number of days to look back (default: 7)
            max_results: Maximum number of emails to fetch (default: 50)
            
        Returns:
            List of email dictionaries with id, subject, sender, date, and raw content
        """
        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        # Format dates for Gmail query (YYYY/MM/DD)
        start_date_str = start_date.strftime('%Y/%m/%d')
        
        # Combine with the original query
        date_query = f"{query} after:{start_date_str}"
        
        return self.fetch_emails(date_query, max_results) 