from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from datetime import timedelta
import logging

from database.session import get_db
from auth.jwt import verify_password, create_access_token, get_password_hash
from auth.models import Token

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Set up router
router = APIRouter()

# For demo purposes, hardcoded users with plain passwords
DEMO_USERS = {
    "admin": {
        "username": "admin",
        "email": "admin@example.com",
        "password": "admin123",  # Plain password for testing
        "is_active": True,
        "scopes": ["emails", "orders", "admin"]
    },
    "user": {
        "username": "user",
        "email": "user@example.com",
        "password": "user123",  # Plain password for testing
        "is_active": True,
        "scopes": ["emails", "orders"]
    }
}

@router.post("/token", response_model=Token)
async def login_for_access_token(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
):
    """
    Get an access token using username and password.
    """
    # In a real app, you would lookup the user in the database
    user = DEMO_USERS.get(form_data.username)
    if not user:
        logger.warning(f"Login attempt with invalid username: {form_data.username}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # For testing purposes, directly compare plain passwords
    if form_data.password != user["password"]:
        logger.warning(f"Failed login attempt for user: {form_data.username}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Create access token
    access_token_expires = timedelta(minutes=30)
    access_token = create_access_token(
        data={"sub": user["username"], "scopes": user["scopes"]},
        expires_delta=access_token_expires
    )
    
    logger.info(f"Successful login for user: {form_data.username}")
    return {"access_token": access_token, "token_type": "bearer"} 