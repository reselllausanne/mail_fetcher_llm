from fastapi import APIRouter, Depends, HTTPException, status, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from typing import List, Dict, Any, Optional
import logging
from datetime import datetime, timedelta

from database.session import get_db
from database.models import Order, EmailLog, ExtractionFailure, Product
from auth.jwt import get_current_user

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Set up router
router = APIRouter()
security = HTTPBearer()

@router.get("/stats", response_model=Dict[str, Any])
async def get_system_stats(
    days: int = 7,
    db: Session = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security)
):
    """
    Get system statistics for monitoring.
    """
    # Calculate date range
    now = datetime.now()
    start_date = now - timedelta(days=days)
    
    # Count total orders
    total_orders = db.query(Order).count()
    
    # Count orders by platform
    shopify_orders = db.query(Order).filter(Order.platform == "shopify").count()
    stockx_orders = db.query(Order).filter(Order.platform == "stockx").count()
    
    # Count orders in date range
    recent_orders = db.query(Order).filter(Order.created_at >= start_date).count()
    
    # Count linked orders
    linked_orders = db.query(Order).filter(
        (Order.shopify_linked_order_id.isnot(None)) | 
        (Order.stockx_linked_order_id.isnot(None))
    ).count()
    
    # Count total emails
    total_emails = db.query(EmailLog).count()
    
    # Count emails by status
    pending_emails = db.query(EmailLog).filter(EmailLog.processing_status == "pending").count()
    processing_emails = db.query(EmailLog).filter(EmailLog.processing_status == "processing").count()
    completed_emails = db.query(EmailLog).filter(EmailLog.processing_status == "completed").count()
    failed_emails = db.query(EmailLog).filter(EmailLog.processing_status == "failed").count()
    
    # Count recent emails
    recent_emails = db.query(EmailLog).filter(EmailLog.processed_date >= start_date).count()
    
    # Count extraction failures
    extraction_failures = db.query(ExtractionFailure).count()
    recent_failures = db.query(ExtractionFailure).filter(ExtractionFailure.created_at >= start_date).count()
    
    # Compile statistics
    stats = {
        "time_period_days": days,
        "orders": {
            "total": total_orders,
            "by_platform": {
                "shopify": shopify_orders,
                "stockx": stockx_orders
            },
            "recent": recent_orders,
            "linked": linked_orders
        },
        "emails": {
            "total": total_emails,
            "by_status": {
                "pending": pending_emails,
                "processing": processing_emails,
                "completed": completed_emails,
                "failed": failed_emails
            },
            "recent": recent_emails
        },
        "extraction_failures": {
            "total": extraction_failures,
            "recent": recent_failures
        }
    }
    
    return stats

@router.get("/failures", response_model=List[Dict[str, Any]])
async def get_extraction_failures(
    limit: int = 100,
    db: Session = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security)
):
    """
    Get recent extraction failures for monitoring.
    """
    failures = db.query(ExtractionFailure).order_by(
        ExtractionFailure.created_at.desc()
    ).limit(limit).all()
    
    result = []
    for failure in failures:
        # Get associated email
        email = db.query(EmailLog).filter(EmailLog.id == failure.email_log_id).first()
        
        # Format failure data
        failure_data = {
            "id": failure.id,
            "failure_type": failure.failure_type,
            "field_name": failure.field_name,
            "attempted_value": failure.attempted_value,
            "error_message": failure.error_message,
            "retry_count": failure.retry_count,
            "resolved": failure.resolved,
            "created_at": failure.created_at,
            "email": {
                "id": email.id if email else None,
                "subject": email.subject if email else None
            } if email else None
        }
        
        result.append(failure_data)
    
    return result

@router.get("/performance", response_model=Dict[str, Any])
async def get_extraction_performance(
    days: int = 30,
    db: Session = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security)
):
    """
    Get extraction performance metrics.
    """
    # Calculate date range
    now = datetime.now()
    start_date = now - timedelta(days=days)
    
    # Get all orders in date range
    recent_orders = db.query(Order).filter(Order.created_at >= start_date).all()
    
    # Initialize counters
    total = len(recent_orders)
    rule_based_count = 0
    llm_count = 0
    hybrid_count = 0
    unknown_count = 0
    
    # Confidence score sums for averaging
    rule_based_confidence_sum = 0
    llm_confidence_sum = 0
    hybrid_confidence_sum = 0
    
    # Process each order
    for order in recent_orders:
        extraction_metadata = order.extraction_metadata
        if not extraction_metadata:
            unknown_count += 1
            continue
        
        extraction_method = extraction_metadata.get("extraction_method")
        confidence = order.extraction_confidence or 0
        
        if extraction_method == "rule_based":
            rule_based_count += 1
            rule_based_confidence_sum += confidence
        elif extraction_method == "llm":
            llm_count += 1
            llm_confidence_sum += confidence
        elif extraction_method == "hybrid":
            hybrid_count += 1
            hybrid_confidence_sum += confidence
        else:
            unknown_count += 1
    
    # Calculate averages
    rule_based_avg = rule_based_confidence_sum / rule_based_count if rule_based_count > 0 else 0
    llm_avg = llm_confidence_sum / llm_count if llm_count > 0 else 0
    hybrid_avg = hybrid_confidence_sum / hybrid_count if hybrid_count > 0 else 0
    
    # Compile performance metrics
    performance = {
        "time_period_days": days,
        "orders_analyzed": total,
        "extraction_methods": {
            "rule_based": {
                "count": rule_based_count,
                "percentage": (rule_based_count / total) * 100 if total > 0 else 0,
                "avg_confidence": rule_based_avg
            },
            "llm": {
                "count": llm_count,
                "percentage": (llm_count / total) * 100 if total > 0 else 0,
                "avg_confidence": llm_avg
            },
            "hybrid": {
                "count": hybrid_count,
                "percentage": (hybrid_count / total) * 100 if total > 0 else 0,
                "avg_confidence": hybrid_avg
            },
            "unknown": {
                "count": unknown_count,
                "percentage": (unknown_count / total) * 100 if total > 0 else 0
            }
        }
    }
    
    return performance

@router.post("/retry-failed", response_model=Dict[str, Any])
async def retry_failed_extractions(
    days: int = 7,
    db: Session = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security)
):
    """
    Queue failed extractions for retry.
    """
    # Calculate date range
    now = datetime.now()
    start_date = now - timedelta(days=days)
    
    # Find failed emails
    failed_emails = db.query(EmailLog).filter(
        EmailLog.processing_status == "failed",
        EmailLog.processed_date >= start_date
    ).all()
    
    # Update status to pending for retry
    for email in failed_emails:
        email.processing_status = "pending"
        email.processing_errors = None
        
        # Update associated failures
        failures = db.query(ExtractionFailure).filter(
            ExtractionFailure.email_log_id == email.id,
            ExtractionFailure.resolved == False
        ).all()
        
        for failure in failures:
            failure.retry_count += 1
        
    db.commit()
    
    return {
        "status": "success",
        "message": f"Queued {len(failed_emails)} failed emails for retry"
    } 