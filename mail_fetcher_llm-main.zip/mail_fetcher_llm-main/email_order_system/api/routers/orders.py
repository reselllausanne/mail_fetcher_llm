from fastapi import APIRouter, Depends, HTTPException, status, Security, Query
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import logging

from database.session import get_db
from database.models import Order, Product, EmailLog
from shopify.graphql_client import ShopifyGraphQLClient
from auth.jwt import get_current_user

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Set up router
router = APIRouter()
security = HTTPBearer()

# Initialize clients
shopify_client = ShopifyGraphQLClient()

@router.get("/", response_model=List[Dict[str, Any]])
async def list_orders(
    platform: Optional[str] = None,
    status: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security)
):
    """
    List orders with optional filtering.
    """
    query = db.query(Order)
    
    # Apply filters
    if platform:
        query = query.filter(Order.platform == platform)
    
    if status:
        query = query.filter(Order.status == status)
    
    # Execute query with pagination
    orders = query.order_by(Order.created_at.desc()).offset(skip).limit(limit).all()
    
    # Format results
    result = []
    for order in orders:
        # Get products for each order
        products = db.query(Product).filter(Product.order_id == order.id).all()
        
        # Format products
        product_list = []
        for product in products:
            product_list.append({
                "id": product.id,
                "product_name": product.product_name,
                "brand": product.brand,
                "size_us": product.size_us,
                "size_eu": product.size_eu,
                "price": product.price,
                "tracking_number": product.tracking_number,
                "carrier": product.carrier
            })
        
        # Format order
        order_dict = {
            "id": order.id,
            "platform": order.platform,
            "order_number": order.order_number,
            "order_date": order.order_date,
            "customer_email": order.customer_email,
            "status": order.status,
            "created_at": order.created_at,
            "updated_at": order.updated_at,
            "products": product_list,
            "extraction_confidence": order.extraction_confidence
        }
        
        # Add linked order info if available
        if order.shopify_linked_order_id:
            linked_order = db.query(Order).filter(Order.id == order.shopify_linked_order_id).first()
            if linked_order:
                order_dict["linked_order"] = {
                    "id": linked_order.id,
                    "platform": linked_order.platform,
                    "order_number": linked_order.order_number
                }
        elif order.stockx_linked_order_id:
            linked_order = db.query(Order).filter(Order.id == order.stockx_linked_order_id).first()
            if linked_order:
                order_dict["linked_order"] = {
                    "id": linked_order.id,
                    "platform": linked_order.platform,
                    "order_number": linked_order.order_number
                }
        
        result.append(order_dict)
    
    return result

@router.get("/{order_id}", response_model=Dict[str, Any])
async def get_order(
    order_id: int,
    db: Session = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security)
):
    """
    Get details for a specific order.
    """
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found"
        )
    
    # Get products
    products = db.query(Product).filter(Product.order_id == order.id).all()
    product_list = []
    for product in products:
        product_list.append({
            "id": product.id,
            "product_name": product.product_name,
            "brand": product.brand,
            "size_us": product.size_us,
            "size_eu": product.size_eu,
            "price": product.price,
            "tracking_number": product.tracking_number,
            "carrier": product.carrier
        })
    
    # Get emails associated with this order
    emails = db.query(EmailLog).filter(EmailLog.order_id == order.id).all()
    email_list = []
    for email in emails:
        email_list.append({
            "id": email.id,
            "subject": email.subject,
            "sender": email.sender,
            "received_date": email.received_date,
            "processing_status": email.processing_status
        })
    
    # Get linked order if any
    linked_order = None
    if order.shopify_linked_order_id:
        linked = db.query(Order).filter(Order.id == order.shopify_linked_order_id).first()
        if linked:
            linked_order = {
                "id": linked.id,
                "platform": linked.platform,
                "order_number": linked.order_number,
                "order_date": linked.order_date,
                "customer_email": linked.customer_email,
                "status": linked.status
            }
    elif order.stockx_linked_order_id:
        linked = db.query(Order).filter(Order.id == order.stockx_linked_order_id).first()
        if linked:
            linked_order = {
                "id": linked.id,
                "platform": linked.platform,
                "order_number": linked.order_number,
                "order_date": linked.order_date,
                "customer_email": linked.customer_email,
                "status": linked.status
            }
    
    # Format result
    result = {
        "id": order.id,
        "platform": order.platform,
        "order_number": order.order_number,
        "order_date": order.order_date,
        "customer_email": order.customer_email,
        "status": order.status,
        "created_at": order.created_at,
        "updated_at": order.updated_at,
        "products": product_list,
        "emails": email_list,
        "linked_order": linked_order,
        "extraction_confidence": order.extraction_confidence,
        "extraction_metadata": order.extraction_metadata
    }
    
    return result

@router.post("/{order_id}/link/{linked_order_id}", response_model=Dict[str, Any])
async def link_orders(
    order_id: int,
    linked_order_id: int,
    db: Session = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security)
):
    """
    Link two orders together.
    """
    # Get both orders
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Order {order_id} not found"
        )
    
    linked_order = db.query(Order).filter(Order.id == linked_order_id).first()
    if not linked_order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Linked order {linked_order_id} not found"
        )
    
    # Validate that orders are from different platforms
    if order.platform == linked_order.platform:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot link orders from the same platform"
        )
    
    # Update the link
    if order.platform == "shopify" and linked_order.platform == "stockx":
        linked_order.shopify_linked_order_id = order.id
        order.stockx_linked_order_id = linked_order.id
    elif order.platform == "stockx" and linked_order.platform == "shopify":
        order.shopify_linked_order_id = linked_order.id
        linked_order.stockx_linked_order_id = order.id
    
    # Copy customer_email if missing
    if not order.customer_email and linked_order.customer_email:
        order.customer_email = linked_order.customer_email
    elif not linked_order.customer_email and order.customer_email:
        linked_order.customer_email = order.customer_email
    
    db.commit()
    
    return {
        "status": "success",
        "message": f"Orders {order_id} and {linked_order_id} linked successfully"
    }

@router.post("/{order_id}/enrich", response_model=Dict[str, Any])
async def enrich_order(
    order_id: int,
    db: Session = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security)
):
    """
    Enrich order data using Shopify GraphQL API.
    """
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found"
        )
    
    # Only Shopify orders can be enriched directly
    if order.platform != "shopify":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Can only enrich Shopify orders directly"
        )
    
    # Extract order number without the # prefix
    order_number = order.order_number
    if order_number.startswith("#"):
        order_number = order_number[1:]
    
    try:
        # Fetch customer email from Shopify
        customer_email = await shopify_client.fetch_order_customer_email(order_number)
        
        if customer_email:
            # Update order
            order.customer_email = customer_email
            db.commit()
            
            # If this order is linked to a StockX order, update that one too
            if order.stockx_linked_order_id:
                stockx_order = db.query(Order).filter(Order.id == order.stockx_linked_order_id).first()
                if stockx_order and not stockx_order.customer_email:
                    stockx_order.customer_email = customer_email
                    db.commit()
            
            return {
                "status": "success",
                "message": f"Order enriched with customer email: {customer_email}",
                "order_id": order.id,
                "customer_email": customer_email
            }
        else:
            return {
                "status": "warning",
                "message": "No customer email found in Shopify",
                "order_id": order.id
            }
            
    except Exception as e:
        logger.error(f"Error enriching order {order_id}: {e}")
        return {
            "status": "error",
            "message": str(e),
            "order_id": order.id
        }

@router.get("/search", response_model=List[Dict[str, Any]])
async def search_orders(
    q: str = Query(..., description="Search query for product name, order number, or customer email"),
    db: Session = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security)
):
    """
    Search orders by various fields.
    """
    # Build search query
    query = db.query(Order).filter(
        (Order.order_number.ilike(f"%{q}%")) |
        (Order.customer_email.ilike(f"%{q}%"))
    )
    
    # Add products to search
    product_orders = db.query(Product.order_id).filter(
        Product.product_name.ilike(f"%{q}%")
    ).distinct()
    
    # Combine queries
    orders = query.all()
    
    # Get orders from product search
    for product_order in product_orders:
        order = db.query(Order).filter(Order.id == product_order.order_id).first()
        if order and order not in orders:
            orders.append(order)
    
    # Format results
    result = []
    for order in orders:
        # Get products for each order
        products = db.query(Product).filter(Product.order_id == order.id).all()
        
        # Format products
        product_list = []
        for product in products:
            product_list.append({
                "id": product.id,
                "product_name": product.product_name,
                "size_us": product.size_us,
                "tracking_number": product.tracking_number
            })
        
        # Format order
        order_dict = {
            "id": order.id,
            "platform": order.platform,
            "order_number": order.order_number,
            "order_date": order.order_date,
            "customer_email": order.customer_email,
            "status": order.status,
            "products": product_list
        }
        
        result.append(order_dict)
    
    return result 