from fastapi import APIRouter, Depends, HTTPException, status, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from typing import List, Dict, Any, Optional
import logging

from database.session import get_db
from database.models import Order, Product
from shopify.graphql_client import ShopifyGraphQLClient
from auth.jwt import get_current_user

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Set up router
router = APIRouter()
security = HTTPBearer()

# Initialize Shopify client
shopify_client = ShopifyGraphQLClient()

@router.get("/orders", response_model=List[Dict[str, Any]])
async def get_shopify_orders(
    limit: int = 10,
    db: Session = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security)
):
    """
    Fetch recent orders from Shopify.
    """
    try:
        # Fetch orders from Shopify
        shopify_orders = await shopify_client.fetch_orders(limit)
        
        # Return the orders
        return shopify_orders
        
    except Exception as e:
        logger.error(f"Error fetching Shopify orders: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error fetching Shopify orders: {str(e)}"
        )

@router.post("/sync", response_model=Dict[str, Any])
async def sync_shopify_orders(
    limit: int = 10,
    db: Session = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security)
):
    """
    Sync orders from Shopify to the local database.
    """
    try:
        # Fetch orders from Shopify
        shopify_orders = await shopify_client.fetch_orders(limit)
        
        # Process each order
        created_count = 0
        updated_count = 0
        
        for shopify_order in shopify_orders:
            # Check if order already exists
            order_number = shopify_order.get("order_number")
            if not order_number:
                continue
                
            existing_order = db.query(Order).filter(
                Order.platform == "shopify",
                Order.order_number == order_number
            ).first()
            
            if existing_order:
                # Update existing order
                if shopify_order.get("order_date"):
                    existing_order.order_date = shopify_order["order_date"]
                    
                if shopify_order.get("customer_email"):
                    existing_order.customer_email = shopify_order["customer_email"]
                
                db.commit()
                updated_count += 1
                
                # Check if we need to create a product
                if shopify_order.get("product_name"):
                    # Check if this product already exists for the order
                    existing_product = db.query(Product).filter(
                        Product.order_id == existing_order.id,
                        Product.product_name == shopify_order["product_name"]
                    ).first()
                    
                    if not existing_product:
                        # Create new product
                        product = Product(
                            order_id=existing_order.id,
                            product_name=shopify_order["product_name"],
                            size_original=shopify_order.get("product_size"),
                            size_us=shopify_order.get("product_size")
                        )
                        
                        db.add(product)
                        db.commit()
                
            else:
                # Create new order
                new_order = Order(
                    platform="shopify",
                    order_number=order_number,
                    order_date=shopify_order.get("order_date"),
                    customer_email=shopify_order.get("customer_email"),
                    status="confirmed"  # Default status for imported orders
                )
                
                db.add(new_order)
                db.commit()
                db.refresh(new_order)
                created_count += 1
                
                # Create product if available
                if shopify_order.get("product_name"):
                    product = Product(
                        order_id=new_order.id,
                        product_name=shopify_order["product_name"],
                        size_original=shopify_order.get("product_size"),
                        size_us=shopify_order.get("product_size")
                    )
                    
                    db.add(product)
                    db.commit()
        
        return {
            "status": "success",
            "message": f"Synced {len(shopify_orders)} orders from Shopify",
            "created": created_count,
            "updated": updated_count
        }
        
    except Exception as e:
        logger.error(f"Error syncing Shopify orders: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error syncing Shopify orders: {str(e)}"
        )

@router.get("/order/{order_number}", response_model=Dict[str, Any])
async def get_shopify_order(
    order_number: str,
    db: Session = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security)
):
    """
    Get details for a specific Shopify order.
    """
    # Ensure order number has the # prefix
    if not order_number.startswith("#"):
        order_number = f"#{order_number}"
    
    try:
        # Check if order exists in the database
        existing_order = db.query(Order).filter(
            Order.platform == "shopify",
            Order.order_number == order_number
        ).first()
        
        if existing_order:
            # Return the existing order
            products = db.query(Product).filter(Product.order_id == existing_order.id).all()
            
            return {
                "id": existing_order.id,
                "platform": existing_order.platform,
                "order_number": existing_order.order_number,
                "order_date": existing_order.order_date,
                "customer_email": existing_order.customer_email,
                "status": existing_order.status,
                "products": [
                    {
                        "id": product.id,
                        "product_name": product.product_name,
                        "size_us": product.size_us,
                        "size_eu": product.size_eu
                    }
                    for product in products
                ]
            }
        
        # If not in database, try to fetch customer email from Shopify
        customer_email = await shopify_client.fetch_order_customer_email(order_number)
        
        if customer_email:
            return {
                "order_number": order_number,
                "customer_email": customer_email,
                "message": "Order found in Shopify but not in local database"
            }
        else:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Order {order_number} not found in Shopify"
            )
            
    except HTTPException:
        raise
        
    except Exception as e:
        logger.error(f"Error getting Shopify order {order_number}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error getting Shopify order: {str(e)}"
        ) 