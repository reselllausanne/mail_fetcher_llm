from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, status, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from typing import List, Dict, Any, Optional
import logging
from datetime import datetime, timedelta

from database.session import get_db
from database.models import EmailLog, Order, Product, ExtractionFailure
# Use email_processing module to avoid conflict with Python's built-in email module
from email_processing.gmail_client import GmailClient
from email_processing.decoder import EmailDecoder
from extractors.hybrid_extractor import HybridExtractor
from auth.jwt import get_current_user

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Set up router
router = APIRouter()
security = HTTPBearer()

# Initialize clients
gmail_client = GmailClient()
email_decoder = EmailDecoder()
hybrid_extractor = HybridExtractor()

@router.get("/", response_model=List[Dict[str, Any]])
async def list_emails(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security)
):
    """
    List processed emails.
    """
    emails = db.query(EmailLog).offset(skip).limit(limit).all()
    return [
        {
            "id": email.id,
            "email_id": email.email_id,
            "subject": email.subject,
            "sender": email.sender,
            "received_date": email.received_date,
            "processed_date": email.processed_date,
            "processing_status": email.processing_status,
            "order_id": email.order_id
        }
        for email in emails
    ]

@router.post("/fetch", status_code=status.HTTP_202_ACCEPTED)
async def fetch_emails(
    background_tasks: BackgroundTasks,
    days: int = 7,
    max_results: int = 50,
    db: Session = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security)
):
    """
    Fetch emails from Gmail and queue them for processing.
    """
    # Add task to fetch emails in the background
    background_tasks.add_task(
        fetch_and_process_emails, days, max_results, db
    )
    
    return {"message": f"Fetching up to {max_results} emails from the last {days} days"}

@router.get("/{email_id}", response_model=Dict[str, Any])
async def get_email(
    email_id: int,
    db: Session = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security)
):
    """
    Get details for a specific email.
    """
    email = db.query(EmailLog).filter(EmailLog.id == email_id).first()
    if not email:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Email not found"
        )
    
    # Get associated order if any
    order = None
    if email.order_id:
        order = db.query(Order).filter(Order.id == email.order_id).first()
        if order:
            products = db.query(Product).filter(Product.order_id == order.id).all()
            order_dict = {
                "id": order.id,
                "platform": order.platform,
                "order_number": order.order_number,
                "order_date": order.order_date,
                "customer_email": order.customer_email,
                "status": order.status,
                "products": [
                    {
                        "id": product.id,
                        "product_name": product.product_name,
                        "brand": product.brand,
                        "size_us": product.size_us,
                        "size_eu": product.size_eu,
                        "price": product.price,
                        "tracking_number": product.tracking_number,
                        "carrier": product.carrier
                    }
                    for product in products
                ]
            }
        else:
            order_dict = None
    else:
        order_dict = None
    
    # Get extraction failures if any
    failures = db.query(ExtractionFailure).filter(ExtractionFailure.email_log_id == email.id).all()
    failures_list = [
        {
            "id": failure.id,
            "failure_type": failure.failure_type,
            "field_name": failure.field_name,
            "attempted_value": failure.attempted_value,
            "error_message": failure.error_message,
            "retry_count": failure.retry_count,
            "resolved": failure.resolved,
            "resolution_method": failure.resolution_method
        }
        for failure in failures
    ]
    
    # Build response
    result = {
        "id": email.id,
        "email_id": email.email_id,
        "subject": email.subject,
        "sender": email.sender,
        "recipient": email.recipient,
        "received_date": email.received_date,
        "processed_date": email.processed_date,
        "processing_status": email.processing_status,
        "order": order_dict,
        "extraction_failures": failures_list
    }
    
    return result

@router.post("/{email_id}/process", response_model=Dict[str, Any])
async def process_email(
    email_id: int,
    db: Session = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security)
):
    """
    Process a specific email to extract order information.
    """
    email = db.query(EmailLog).filter(EmailLog.id == email_id).first()
    if not email:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Email not found"
        )
    
    # Process the email
    result = await process_single_email(email, db)
    
    return result

async def fetch_and_process_emails(days: int, max_results: int, db: Session):
    """
    Fetch emails from Gmail and process them.
    """
    try:
        # Fetch emails from Gmail
        emails = gmail_client.fetch_emails_by_date_range(
            query='subject:StockX OR subject:Shopify',
            days=days,
            max_results=max_results
        )
        
        logger.info(f"Fetched {len(emails)} emails from Gmail")
        
        # Process each email
        for email_data in emails:
            # Check if email already exists in database
            existing_email = db.query(EmailLog).filter(
                EmailLog.email_id == email_data['email_id']
            ).first()
            
            if existing_email:
                logger.info(f"Email {email_data['email_id']} already exists, skipping")
                continue
            
            # Create new email log entry
            email_log = EmailLog(
                email_id=email_data['email_id'],
                subject=email_data['subject'],
                sender=email_data['sender'],
                received_date=email_data.get('received_date'),
                raw_content=email_data['raw_content'],
                processing_status='pending'
            )
            
            db.add(email_log)
            db.commit()
            db.refresh(email_log)
            
            # Process the email to extract order information
            await process_single_email(email_log, db)
        
        return {"processed": len(emails)}
        
    except Exception as e:
        logger.error(f"Error fetching and processing emails: {e}")
        return {"error": str(e)}

async def process_single_email(email_log: EmailLog, db: Session) -> Dict[str, Any]:
    """
    Process a single email to extract order information.
    """
    try:
        # Update processing status
        email_log.processing_status = 'processing'
        db.commit()
        
        # Decode email
        decoded_email = email_decoder.process_email({
            'raw_content': email_log.raw_content
        })
        
        # Update email log with decoded content
        email_log.decoded_content = decoded_email.get('decoded_content')
        db.commit()
        
        # Fetch recent orders for context
        recent_orders = []
        recent_order_records = db.query(Order).order_by(
            Order.created_at.desc()
        ).limit(20).all()
        
        for order in recent_order_records:
            products = db.query(Product).filter(Product.order_id == order.id).all()
            if products:
                recent_orders.append({
                    "platform": order.platform,
                    "order_number": order.order_number,
                    "order_date": order.order_date.isoformat() if order.order_date else None,
                    "customer_email": order.customer_email,
                    "product_name": products[0].product_name if products else None,
                    "product_size": products[0].size_us if products else None
                })
        
        # Extract order information
        extraction_result = await hybrid_extractor.extract(decoded_email, recent_orders)
        
        if "error" in extraction_result:
            # Record extraction failure
            email_log.processing_status = 'failed'
            email_log.processing_errors = {"message": extraction_result["error"]}
            db.commit()
            
            failure = ExtractionFailure(
                email_log_id=email_log.id,
                failure_type="extraction_error",
                error_message=extraction_result["error"]
            )
            db.add(failure)
            db.commit()
            
            return {
                "status": "error",
                "message": extraction_result["error"],
                "email_id": email_log.id
            }
        
        # Create or update order
        platform = extraction_result.get("platform")
        order_number = extraction_result.get("order_number")
        
        if not platform or not order_number:
            email_log.processing_status = 'incomplete'
            email_log.processing_errors = {"message": "Missing platform or order number"}
            db.commit()
            
            return {
                "status": "incomplete",
                "message": "Could not determine platform or order number",
                "email_id": email_log.id
            }
        
        # Check if order already exists
        existing_order = db.query(Order).filter(
            Order.platform == platform,
            Order.order_number == order_number
        ).first()
        
        if existing_order:
            # Update existing order
            order = existing_order
            
            # Update order details if better data is available
            if extraction_result.get("order_date"):
                order.order_date = extraction_result["order_date"]
            
            if extraction_result.get("customer_email"):
                order.customer_email = extraction_result["customer_email"]
            
            if extraction_result.get("order_status"):
                order.status = extraction_result["order_status"]
            
            # Update extraction metadata
            order.extraction_metadata = extraction_result
            
            # Calculate average confidence
            confidence_scores = extraction_result.get("confidence_scores", {})
            if confidence_scores:
                total = sum(confidence_scores.values())
                count = len(confidence_scores)
                avg_confidence = total / count if count > 0 else 0
                order.extraction_confidence = avg_confidence
            
            db.commit()
            
        else:
            # Create new order
            order = Order(
                platform=platform,
                order_number=order_number,
                order_date=extraction_result.get("order_date"),
                customer_email=extraction_result.get("customer_email"),
                status=extraction_result.get("order_status", "unknown"),
                extraction_metadata=extraction_result
            )
            
            # Calculate average confidence
            confidence_scores = extraction_result.get("confidence_scores", {})
            if confidence_scores:
                total = sum(confidence_scores.values())
                count = len(confidence_scores)
                avg_confidence = total / count if count > 0 else 0
                order.extraction_confidence = avg_confidence
            
            db.add(order)
            db.commit()
            db.refresh(order)
        
        # Create or update product
        if extraction_result.get("product_name"):
            # Check if product already exists for this order
            existing_product = db.query(Product).filter(
                Product.order_id == order.id,
                Product.product_name == extraction_result["product_name"]
            ).first()
            
            if existing_product:
                # Update existing product
                product = existing_product
                
                # Update product details if better data is available
                if extraction_result.get("product_size"):
                    product.size_original = extraction_result["product_size"]
                    product.size_us = extraction_result["product_size"]
                
                if extraction_result.get("converted_size_eu"):
                    product.size_eu = extraction_result["converted_size_eu"]
                
                if extraction_result.get("price"):
                    product.price = float(extraction_result["price"].replace("$", "").replace(",", ""))
                
                if extraction_result.get("tracking_number"):
                    product.tracking_number = extraction_result["tracking_number"]
                
                if extraction_result.get("carrier"):
                    product.carrier = extraction_result["carrier"]
                
                db.commit()
                
            else:
                # Create new product
                try:
                    price_float = None
                    if extraction_result.get("price"):
                        price_str = extraction_result["price"].replace("$", "").replace(",", "")
                        price_float = float(price_str)
                except Exception:
                    price_float = None
                
                product = Product(
                    order_id=order.id,
                    product_name=extraction_result["product_name"],
                    size_original=extraction_result.get("product_size"),
                    size_us=extraction_result.get("product_size"),
                    size_eu=extraction_result.get("converted_size_eu"),
                    price=price_float,
                    tracking_number=extraction_result.get("tracking_number"),
                    carrier=extraction_result.get("carrier")
                )
                
                db.add(product)
                db.commit()
        
        # Link email to order
        email_log.order_id = order.id
        email_log.processing_status = 'completed'
        db.commit()
        
        return {
            "status": "success",
            "email_id": email_log.id,
            "order_id": order.id,
            "platform": order.platform,
            "order_number": order.order_number,
            "extraction_method": extraction_result.get("extraction_method", "unknown")
        }
        
    except Exception as e:
        logger.error(f"Error processing email {email_log.id}: {e}")
        
        # Update email log with error
        email_log.processing_status = 'failed'
        email_log.processing_errors = {"message": str(e)}
        db.commit()
        
        # Record extraction failure
        failure = ExtractionFailure(
            email_log_id=email_log.id,
            failure_type="system_error",
            error_message=str(e)
        )
        db.add(failure)
        db.commit()
        
        return {
            "status": "error",
            "message": str(e),
            "email_id": email_log.id
        } 