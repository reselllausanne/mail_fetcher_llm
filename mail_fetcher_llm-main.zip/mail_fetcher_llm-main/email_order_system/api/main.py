from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import os
from datetime import timedelta
import logging
from typing import Optional, List

from api.routers import emails, orders, shopify, monitoring, auth
from auth.jwt import oauth2_scheme, create_access_token
from auth.models import User, UserCreate, Token
from database.session import get_db
from database.models import Base
from database.session import engine

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Email Order Extraction & Linking System",
    description="API for processing order emails and linking across platforms",
    version="1.0.0",
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, restrict to specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(emails.router, prefix="/api/emails", tags=["emails"])
app.include_router(orders.router, prefix="/api/orders", tags=["orders"])
app.include_router(shopify.router, prefix="/api/shopify", tags=["shopify"])
app.include_router(monitoring.router, prefix="/api/monitoring", tags=["monitoring"])

# Health check endpoint
@app.get("/health", tags=["health"])
async def health_check():
    return {"status": "ok"}

# Root endpoint
@app.get("/", tags=["root"])
async def root():
    return {
        "message": "Email Order Extraction & Linking System API",
        "docs": "/docs",
    }

# Create database tables
@app.on_event("startup")
async def startup_db_client():
    try:
        # Create tables if they don't exist
        Base.metadata.create_all(bind=engine)
        logger.info("Database tables created or verified")
    except Exception as e:
        logger.error(f"Failed to initialize database: {e}")
        raise

if __name__ == "__main__":
    uvicorn.run("api.main:app", host="0.0.0.0", port=8000, reload=True) 