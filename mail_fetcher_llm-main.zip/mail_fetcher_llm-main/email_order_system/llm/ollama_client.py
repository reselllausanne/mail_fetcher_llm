import os
import json
import logging
import hashlib
import time
from typing import Dict, Any, Optional
import httpx
from dotenv import load_dotenv
import re
import asyncio

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class OllamaClient:
    """Client for interacting with Ollama LLM API."""
    
    def __init__(self):
        """Initialize the Ollama client with configuration."""
        self.base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
        self.model = os.getenv("OLLAMA_MODEL", "llama3.2")
        self.timeout = int(os.getenv("OLLAMA_TIMEOUT", "120"))
        
        # Load the prompt template
        current_dir = os.path.dirname(os.path.abspath(__file__))
        prompt_path = os.path.join(current_dir, "llama_prompt.txt")
        try:
            with open(prompt_path, "r", encoding="utf-8") as f:
                self.prompt_template = f.read()
            logger.info("Loaded LLaMA prompt template")
        except Exception as e:
            logger.error(f"Error loading prompt template: {e}")
            self.prompt_template = "Extract order information from this email: {{EMAIL_CONTENT}}"
    
    async def extract_order_info(self, email_content: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Extract order information from email content using Ollama.
        
        Args:
            email_content: The email content to analyze
            context: Optional context information like recent orders for linking
            
        Returns:
            Dictionary with extracted order information
        """
        try:
            # Prepare the email content
            clean_content = self._sanitize_email(email_content)
            
            # Generate prompt by replacing placeholder
            prompt = self.prompt_template.replace("{{EMAIL_CONTENT}}", clean_content)
            
            # Generate cache key to avoid duplicate processing
            cache_key = self._generate_cache_key(clean_content)
            
            # Call Ollama API
            response = await self._call_ollama_api(prompt)
            
            # Parse the response
            parsed_response = self._parse_ollama_response(response)
            
            # Add metadata
            if parsed_response:
                # Add cache key for potential future lookups
                parsed_response["_cache_key"] = cache_key
                
                # Add timestamp
                parsed_response["_timestamp"] = time.time()
                
                # Add additional context if needed
                if context:
                    # Add linking information if applicable
                    if "recent_orders" in context and parsed_response.get("platform") == "stockx":
                        linked_order = self._try_link_order(parsed_response, context["recent_orders"])
                        if linked_order:
                            parsed_response["linked_order_id"] = linked_order["order_number"]
                            if "customer_email" in linked_order and linked_order["customer_email"]:
                                parsed_response["customer_email"] = linked_order["customer_email"]
                                parsed_response["confidence_scores"]["customer_email"] = 0.9
            
            return parsed_response
            
        except Exception as e:
            logger.error(f"Error extracting order info with Ollama: {e}")
            # Return a basic error response
            return {
                "error": str(e),
                "platform": None,
                "order_number": None,
                "confidence_scores": {
                    "order_number": 0.0,
                    "product_name": 0.0,
                    "price": 0.0,
                    "tracking_number": 0.0,
                    "customer_email": 0.0
                }
            }
    
    async def _call_ollama_api(self, prompt: str) -> str:
        """
        Call the Ollama API with the given prompt.
        
        Args:
            prompt: The prompt to send to Ollama
            
        Returns:
            The response text from Ollama
        """
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                # Configure the request to Ollama
                url = f"{self.base_url}/api/generate"
                payload = {
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "temperature": 0.1,  # Low temperature for more deterministic results
                        "num_predict": 2048
                    }
                }
                
                # Make the request
                logger.info(f"Calling Ollama API with model: {self.model}")
                start_time = time.time()
                
                response = await client.post(url, json=payload)
                response.raise_for_status()
                
                result = response.json()
                elapsed_time = time.time() - start_time
                
                logger.info(f"Ollama API call completed in {elapsed_time:.2f} seconds")
                
                return result.get("response", "")
                
        except httpx.RequestError as e:
            logger.error(f"Error making request to Ollama API: {e}")
            raise Exception(f"Failed to connect to Ollama: {e}")
        
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error from Ollama API: {e.response.status_code} - {e.response.text}")
            raise Exception(f"Ollama API returned error: {e.response.status_code}")
        
        except Exception as e:
            logger.error(f"Unexpected error calling Ollama API: {e}")
            raise
    
    def _parse_ollama_response(self, response_text: str) -> Dict[str, Any]:
        """
        Parse the JSON response from Ollama.
        
        Args:
            response_text: The text response from Ollama
            
        Returns:
            Dictionary with parsed JSON data
        """
        try:
            # Extract JSON from the response
            json_match = re.search(r'```json\s*([\s\S]*?)\s*```', response_text)
            
            if json_match:
                json_str = json_match.group(1).strip()
                return json.loads(json_str)
            
            # If no JSON block found, try to parse the entire response
            try:
                return json.loads(response_text)
            except json.JSONDecodeError:
                # If that fails, try to find any JSON-like structure
                potential_json = re.search(r'(\{[\s\S]*\})', response_text)
                if potential_json:
                    try:
                        return json.loads(potential_json.group(1))
                    except json.JSONDecodeError:
                        pass
            
            logger.error(f"Could not extract valid JSON from Ollama response")
            return {}
            
        except Exception as e:
            logger.error(f"Error parsing Ollama response: {e}")
            return {}
    
    def _sanitize_email(self, email_content: str) -> str:
        """
        Clean and sanitize email content for the LLM.
        
        Args:
            email_content: The raw email content
            
        Returns:
            Sanitized email content
        """
        if not email_content:
            return ""
            
        # Truncate if too long
        max_length = 8000
        if len(email_content) > max_length:
            email_content = email_content[:max_length] + "... [truncated]"
        
        # Replace multiple newlines with a single newline
        email_content = re.sub(r'\n{3,}', '\n\n', email_content)
        
        # Remove potentially problematic characters
        email_content = re.sub(r'[^\x00-\x7F]+', ' ', email_content)
        
        return email_content
    
    def _generate_cache_key(self, content: str) -> str:
        """
        Generate a cache key for the email content.
        
        Args:
            content: The email content
            
        Returns:
            MD5 hash of the content
        """
        return hashlib.md5(content.encode('utf-8')).hexdigest()
    
    def _try_link_order(self, stockx_order: Dict[str, Any], recent_shopify_orders: list) -> Optional[Dict[str, Any]]:
        """
        Try to link a StockX order with recent Shopify orders.
        
        Args:
            stockx_order: The StockX order data
            recent_shopify_orders: List of recent Shopify orders
            
        Returns:
            Matching Shopify order or None
        """
        if not recent_shopify_orders or not stockx_order.get("product_name") or not stockx_order.get("product_size"):
            return None
        
        stockx_product = stockx_order["product_name"].lower()
        stockx_size = stockx_order["product_size"]
        
        for shopify_order in recent_shopify_orders:
            if not shopify_order.get("product_name") or not shopify_order.get("product_size"):
                continue
            
            shopify_product = shopify_order["product_name"].lower()
            shopify_size = shopify_order["product_size"]
            
            # Check for product name similarity
            # This is a simple comparison, could be improved with fuzzy matching
            if stockx_product in shopify_product or shopify_product in stockx_product:
                # Check for exact size match
                if stockx_size == shopify_size:
                    return shopify_order
        
        return None 