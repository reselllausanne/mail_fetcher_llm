import pytest
import os
import sys
import json
from pathlib import Path

# Add parent directory to sys.path
sys.path.insert(0, str(Path(__file__).parent.parent))

from extractors.rule_based import RuleBasedExtractor
from utils.size_converter import SizeConverter

# Sample test data
SHOPIFY_EMAIL = """
Subject: ✅ Order Confirmed – #1001
Body:
Product: Nike Dunk Low
Size: US10
Date: April 1, 2024
Price: $150.00
"""

STOCKX_EMAIL = """
Subject: 📦 Your item has shipped
Body:
Order: 73833763-73733522
Product: Nike Dunk Low
Size: US 10
Date: April 2, 2024
Tracking: 1Z9999999999999999
"""

def test_rule_based_extractor_shopify():
    """Test rule-based extractor on Shopify email."""
    extractor = RuleBasedExtractor()
    result = extractor.extract_order_info(SHOPIFY_EMAIL)
    
    # Check platform detection
    assert result["platform"] == "shopify"
    
    # Check order number extraction
    assert result["order_number"] == "#1001"
    
    # Check product name extraction
    assert result["product_name"] == "Nike Dunk Low"
    
    # Check size extraction
    assert result["product_size"] is not None
    
    # Check price extraction
    assert result["price"] == "$150.00"
    
    # Check confidence scores
    assert result["confidence_scores"]["order_number"] > 0.8
    assert result["confidence_scores"]["product_name"] > 0.8
    assert result["confidence_scores"]["price"] > 0.8

def test_rule_based_extractor_stockx():
    """Test rule-based extractor on StockX email."""
    extractor = RuleBasedExtractor()
    result = extractor.extract_order_info(STOCKX_EMAIL)
    
    # Check platform detection
    assert result["platform"] == "stockx"
    
    # Check order number extraction
    assert result["order_number"] == "73833763-73733522"
    
    # Check product name extraction
    assert result["product_name"] == "Nike Dunk Low"
    
    # Check size extraction
    assert result["product_size"] is not None
    
    # Check tracking number extraction
    assert result["tracking_number"] == "1Z9999999999999999"
    
    # Check confidence scores
    assert result["confidence_scores"]["order_number"] > 0.8
    assert result["confidence_scores"]["product_name"] > 0.8
    assert result["confidence_scores"]["tracking_number"] > 0.8

def test_size_converter():
    """Test size conversion utility."""
    converter = SizeConverter()
    
    # Test US to EU conversion
    result = converter.normalize_size("US 10", "Nike Dunk Low")
    assert result["us"] == "US 10 M"
    assert result["eu"] == "EU 44"
    
    # Test half size
    result = converter.normalize_size("US 10.5", "Nike Air Jordan")
    assert result["us"] == "US 10.5 M"
    assert result["eu"] == "EU 44.5"
    
    # Test women's size
    result = converter.normalize_size("US 8 W", "Nike Air Force 1")
    assert result["us"] == "US 8 W"
    assert result["eu"] == "EU 38.5"
    
    # Test brand detection
    result = converter.normalize_size("10", "Adidas Yeezy Boost")
    assert result["brand"] == "adidas"

if __name__ == "__main__":
    # Run tests manually
    test_rule_based_extractor_shopify()
    test_rule_based_extractor_stockx()
    test_size_converter()
    print("All tests passed!") 