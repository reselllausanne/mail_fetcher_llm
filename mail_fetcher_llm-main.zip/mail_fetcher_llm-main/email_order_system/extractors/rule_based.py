import re
import logging
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime
import json

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RuleBasedExtractor:
    """
    Extract order information from emails using rule-based regex patterns.
    """
    
    def __init__(self):
        """Initialize the extractor with regex patterns."""
        # Shopify order number patterns
        self.shopify_order_patterns = [
            r'Order\s*(?:Number|#|No\.?):?\s*#?(\d+)',  # Order Number: #1234 or Order #1234
            r'order\s*(?:confirmation|confirmed).*?#(\d+)',  # order confirmation #1234
            r'#(\d+)\s*(?:is confirmed|has been received)',  # #1234 is confirmed
            r'Shopify.*?Order.*?#(\d+)'  # Shopify Order #1234
        ]
        
        # StockX order number patterns
        self.stockx_order_patterns = [
            r'Order:?\s*([A-Z0-9]+-[A-Z0-9]+)',  # StockX order format: ABCDE-12345
            r'Order:?\s*(\d+-[A-Z0-9]+)',  # StockX order format: 12345-ABCDE
            r'Order\s*(?:Number|#|No\.?):?\s*([A-Z0-9]+-[A-Z0-9]+)',  # Order Number: ABCDE-12345
            r'Order\s*(?:Number|#|No\.?):?\s*(\d+-[A-Z0-9]+)',  # Order Number: 12345-ABCDE
            r'Order\s*(?:Number|#|No\.?):?\s*(\d+-\d+)'  # Order Number: 12345-67890
        ]
        
        # Tracking number patterns
        self.tracking_patterns = {
            'UPS': [
                r'1Z[A-Z0-9]{16}',  # UPS format
                r'1Z\s?[A-Z0-9]{3}\s?[A-Z0-9]{3}\s?[A-Z0-9]{2}\s?[A-Z0-9]{4}\s?[A-Z0-9]{3}\s?[A-Z0-9]'
            ],
            'USPS': [
                r'94\d{20}',  # USPS format
                r'94\d{2}\s?\d{4}\s?\d{4}\s?\d{4}\s?\d{4}\s?\d{2}',
                r'92\d{2}\s?\d{4}\s?\d{4}\s?\d{4}\s?\d{4}\s?\d{2}'
            ],
            'FedEx': [
                r'(\b\d{12}\b)',  # FedEx 12-digit
                r'(\b\d{15}\b)',  # FedEx 15-digit
                r'(\b\d{20}\b)'   # FedEx 20-digit
            ],
            'DHL': [
                r'\b\d{10}\b',  # DHL format
                r'\b\d{11}\b'
            ]
        }
        
        # Size patterns
        self.size_patterns = [
            r'Size:?\s*(US\.?\s*\d+(?:\.5)?(?:\s*[MW])?)',  # Size: US 10 or Size: US 10.5 or Size: US 10M
            r'Size:?\s*(\d+(?:\.5)?(?:\s*[MW])?\s*US)',  # Size: 10 US or Size: 10.5 US
            r'Size:?\s*(\d+(?:\.5)?)',  # Size: 10 or Size: 10.5
            r'\b(US\.?\s*\d+(?:\.5)?(?:\s*[MW])?)\b',  # US 10 or US 10.5 M
            r'\b(\d+(?:\.5)?(?:\s*[MW])?\s*US)\b'  # 10 US or 10.5 M US
        ]
        
        # Product name patterns
        self.product_patterns = [
            r'Product:?\s*(.*?)(?:Size|Price|\$|\n)',  # Product: Nike Dunk Low
            r'Item:?\s*(.*?)(?:Size|Price|\$|\n)',  # Item: Nike Dunk Low
            r'Name:?\s*(.*?)(?:Size|Price|\$|\n)'  # Name: Nike Dunk Low
        ]
        
        # Price patterns
        self.price_patterns = [
            r'(?:Price|Total|Amount):?\s*(\$\d+\.\d{2})',  # Price: $150.00
            r'(?:Price|Total|Amount):?\s*(\$\d+)',  # Price: $150
            r'(?:Price|Total|Amount):?\s*(\d+\.\d{2}\s*USD)',  # Price: 150.00 USD
            r'(\$\d+\.\d{2})',  # $150.00
            r'(€\d+\.\d{2})',  # €150.00
            r'(£\d+\.\d{2})'   # £150.00
        ]
        
        # Date patterns
        self.date_patterns = [
            r'(?:Date|Ordered on):?\s*(\w+\s+\d{1,2},?\s+\d{4})',  # April 1, 2024
            r'(?:Date|Ordered on):?\s*(\d{1,2}\s+\w+\s+\d{4})',  # 1 April 2024
            r'(?:Date|Ordered on):?\s*(\d{1,2}/\d{1,2}/\d{4})',  # 4/1/2024
            r'(?:Date|Ordered on):?\s*(\d{4}-\d{1,2}-\d{1,2})'   # 2024-04-01
        ]
        
        # Email patterns
        self.email_patterns = [
            r'\b([a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+)\b'
        ]
    
    def extract_order_info(self, email_text: str, platform_hint: Optional[str] = None) -> Dict[str, Any]:
        """
        Extract order information from email text.
        
        Args:
            email_text: Decoded email text
            platform_hint: Optional hint about the email platform (shopify/stockx)
            
        Returns:
            Dictionary with extracted order information and confidence scores
        """
        # Initialize result dictionary with default values and confidence scores
        result = {
            "platform": None,
            "order_number": None,
            "order_date": None,
            "product_name": None,
            "product_size": None,
            "price": None,
            "tracking_number": None,
            "carrier": None,
            "customer_email": None,
            "order_status": None,
            "confidence_scores": {
                "platform": 0.0,
                "order_number": 0.0,
                "product_name": 0.0,
                "product_size": 0.0,
                "price": 0.0,
                "tracking_number": 0.0,
                "customer_email": 0.0
            }
        }
        
        # Detect platform if not provided
        if platform_hint:
            result["platform"] = platform_hint
            result["confidence_scores"]["platform"] = 0.8  # Good confidence but not 100%
        else:
            platform, confidence = self._detect_platform(email_text)
            result["platform"] = platform
            result["confidence_scores"]["platform"] = confidence
        
        # Extract order number based on platform
        if result["platform"] == "shopify":
            order_number, confidence = self._extract_shopify_order_number(email_text)
            if order_number:
                result["order_number"] = order_number
                result["confidence_scores"]["order_number"] = confidence
        elif result["platform"] == "stockx":
            order_number, confidence = self._extract_stockx_order_number(email_text)
            if order_number:
                result["order_number"] = order_number
                result["confidence_scores"]["order_number"] = confidence
        
        # Extract other fields regardless of platform
        product_name, product_confidence = self._extract_product_name(email_text)
        if product_name:
            result["product_name"] = product_name
            result["confidence_scores"]["product_name"] = product_confidence
        
        size, size_confidence = self._extract_size(email_text)
        if size:
            result["product_size"] = size
            result["confidence_scores"]["product_size"] = size_confidence
        
        price, price_confidence = self._extract_price(email_text)
        if price:
            result["price"] = price
            result["confidence_scores"]["price"] = price_confidence
        
        tracking_number, carrier, tracking_confidence = self._extract_tracking_number(email_text)
        if tracking_number:
            result["tracking_number"] = tracking_number
            result["carrier"] = carrier
            result["confidence_scores"]["tracking_number"] = tracking_confidence
        
        date_str = self._extract_date(email_text)
        if date_str:
            result["order_date"] = date_str
        
        email, email_confidence = self._extract_email(email_text)
        if email:
            result["customer_email"] = email
            result["confidence_scores"]["customer_email"] = email_confidence
        
        # Determine order status
        result["order_status"] = self._determine_order_status(email_text)
        
        return result
    
    def _detect_platform(self, email_text: str) -> Tuple[str, float]:
        """
        Detect the platform (Shopify or StockX) from the email text.
        
        Args:
            email_text: The email text to analyze
            
        Returns:
            Tuple of (platform_name, confidence_score)
        """
        # Check for explicit platform mentions
        shopify_mentions = len(re.findall(r'\bshopify\b', email_text.lower()))
        stockx_mentions = len(re.findall(r'\bstockx\b', email_text.lower()))
        
        # Check for platform-specific patterns
        shopify_patterns_matched = sum(1 for pattern in self.shopify_order_patterns if re.search(pattern, email_text, re.IGNORECASE))
        stockx_patterns_matched = sum(1 for pattern in self.stockx_order_patterns if re.search(pattern, email_text, re.IGNORECASE))
        
        # Calculate scores
        shopify_score = shopify_mentions * 0.3 + shopify_patterns_matched * 0.7
        stockx_score = stockx_mentions * 0.3 + stockx_patterns_matched * 0.7
        
        # Normalize to confidence score
        if shopify_score > stockx_score:
            confidence = min(1.0, 0.5 + (shopify_score - stockx_score) * 0.25)
            return "shopify", confidence
        elif stockx_score > shopify_score:
            confidence = min(1.0, 0.5 + (stockx_score - shopify_score) * 0.25)
            return "stockx", confidence
        else:
            return "unknown", 0.0
    
    def _extract_shopify_order_number(self, email_text: str) -> Tuple[Optional[str], float]:
        """
        Extract Shopify order number from email text.
        
        Args:
            email_text: The email text to extract from
            
        Returns:
            Tuple of (order_number, confidence_score)
        """
        for pattern in self.shopify_order_patterns:
            match = re.search(pattern, email_text, re.IGNORECASE)
            if match:
                order_number = match.group(1)
                # Add # prefix if not present for consistency
                if not order_number.startswith('#'):
                    order_number = f"#{order_number}"
                return order_number, 1.0  # High confidence for regex match
        
        return None, 0.0
    
    def _extract_stockx_order_number(self, email_text: str) -> Tuple[Optional[str], float]:
        """
        Extract StockX order number from email text.
        
        Args:
            email_text: The email text to extract from
            
        Returns:
            Tuple of (order_number, confidence_score)
        """
        for pattern in self.stockx_order_patterns:
            match = re.search(pattern, email_text, re.IGNORECASE)
            if match:
                return match.group(1), 1.0  # High confidence for regex match
        
        return None, 0.0
    
    def _extract_tracking_number(self, email_text: str) -> Tuple[Optional[str], Optional[str], float]:
        """
        Extract tracking number and carrier from email text.
        
        Args:
            email_text: The email text to extract from
            
        Returns:
            Tuple of (tracking_number, carrier, confidence_score)
        """
        for carrier, patterns in self.tracking_patterns.items():
            for pattern in patterns:
                match = re.search(pattern, email_text)
                if match:
                    tracking_number = match.group(0).replace(" ", "")  # Remove spaces
                    
                    # Check if the tracking number is in a tracking context
                    context_check = re.search(r'(?:tracking|track).*?' + re.escape(tracking_number), 
                                             email_text, re.IGNORECASE | re.DOTALL)
                    
                    confidence = 1.0 if context_check else 0.8  # Higher confidence if in tracking context
                    return tracking_number, carrier, confidence
        
        return None, None, 0.0
    
    def _extract_size(self, email_text: str) -> Tuple[Optional[str], float]:
        """
        Extract product size from email text.
        
        Args:
            email_text: The email text to extract from
            
        Returns:
            Tuple of (size, confidence_score)
        """
        for pattern in self.size_patterns:
            match = re.search(pattern, email_text, re.IGNORECASE)
            if match:
                size = match.group(1)
                # Check if in size context
                context_check = re.search(r'size.*?' + re.escape(size), 
                                         email_text, re.IGNORECASE | re.DOTALL)
                
                confidence = 1.0 if context_check else 0.8
                return size, confidence
        
        return None, 0.0
    
    def _extract_product_name(self, email_text: str) -> Tuple[Optional[str], float]:
        """
        Extract product name from email text.
        
        Args:
            email_text: The email text to extract from
            
        Returns:
            Tuple of (product_name, confidence_score)
        """
        for pattern in self.product_patterns:
            match = re.search(pattern, email_text, re.IGNORECASE)
            if match:
                product_name = match.group(1).strip()
                # Clean up multi-line or excessive whitespace
                product_name = re.sub(r'\s+', ' ', product_name)
                
                # If too long or too short, reduce confidence
                if len(product_name) < 5 or len(product_name) > 100:
                    return product_name, 0.6
                
                return product_name, 1.0
        
        # Try to find product name from Nike/Adidas/Jordan/Yeezy context
        brands = ['Nike', 'Adidas', 'Jordan', 'Yeezy']
        for brand in brands:
            pattern = r'(?:' + re.escape(brand) + r')\s+([A-Za-z0-9\s]+(?:Low|Mid|High)?)'
            match = re.search(pattern, email_text, re.IGNORECASE)
            if match:
                product_name = f"{brand} {match.group(1).strip()}"
                # Clean up product name
                product_name = re.sub(r'\s+', ' ', product_name)
                return product_name, 0.8
        
        return None, 0.0
    
    def _extract_price(self, email_text: str) -> Tuple[Optional[str], float]:
        """
        Extract price from email text.
        
        Args:
            email_text: The email text to extract from
            
        Returns:
            Tuple of (price, confidence_score)
        """
        for pattern in self.price_patterns:
            match = re.search(pattern, email_text, re.IGNORECASE)
            if match:
                price = match.group(1)
                
                # Check if in price context
                context_check = re.search(r'(?:price|total|amount|subtotal).*?' + re.escape(price), 
                                         email_text, re.IGNORECASE | re.DOTALL)
                
                confidence = 1.0 if context_check else 0.7
                return price, confidence
        
        return None, 0.0
    
    def _extract_date(self, email_text: str) -> Optional[str]:
        """
        Extract date from email text and convert to ISO format.
        
        Args:
            email_text: The email text to extract from
            
        Returns:
            Date string in ISO format if found, None otherwise
        """
        for pattern in self.date_patterns:
            match = re.search(pattern, email_text, re.IGNORECASE)
            if match:
                date_str = match.group(1)
                try:
                    # Try different date formats
                    for fmt in [
                        '%B %d, %Y',  # April 1, 2024
                        '%B %d %Y',   # April 1 2024
                        '%d %B %Y',   # 1 April 2024
                        '%m/%d/%Y',   # 4/1/2024
                        '%Y-%m-%d'    # 2024-04-01
                    ]:
                        try:
                            parsed_date = datetime.strptime(date_str, fmt)
                            return parsed_date.isoformat()
                        except ValueError:
                            continue
                except Exception:
                    pass
        
        return None
    
    def _extract_email(self, email_text: str) -> Tuple[Optional[str], float]:
        """
        Extract customer email from email text.
        
        Args:
            email_text: The email text to extract from
            
        Returns:
            Tuple of (email, confidence_score)
        """
        for pattern in self.email_patterns:
            matches = re.findall(pattern, email_text)
            if matches:
                # Filter out common non-customer emails
                filtered_emails = [
                    email for email in matches 
                    if not any(domain in email.lower() for domain in [
                        'shopify.com', 'stockx.com', 'support', 'help', 'noreply', 'no-reply'
                    ])
                ]
                
                if filtered_emails:
                    return filtered_emails[0], 1.0
        
        return None, 0.0
    
    def _determine_order_status(self, email_text: str) -> str:
        """
        Determine the order status from email text.
        
        Args:
            email_text: The email text to analyze
            
        Returns:
            Order status: confirmed, shipped, delivered, canceled, or unknown
        """
        email_text_lower = email_text.lower()
        
        if any(term in email_text_lower for term in ['shipped', 'shipping', 'has shipped', 'on its way']):
            return "shipped"
        elif any(term in email_text_lower for term in ['delivered', 'has been delivered', 'was delivered']):
            return "delivered"
        elif any(term in email_text_lower for term in ['confirmed', 'confirmation', 'thank you for your order']):
            return "confirmed"
        elif any(term in email_text_lower for term in ['canceled', 'cancelled', 'order cancellation']):
            return "canceled"
        else:
            return "unknown" 