import logging
from typing import Dict, Any, Optional, List
import json
import asyncio
from datetime import datetime, timedelta

from extractors.rule_based import RuleBasedExtractor
from llm.ollama_client import OllamaClient
from utils.size_converter import SizeConverter

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class HybridExtractor:
    """
    Hybrid order information extractor that combines rule-based and LLM approaches.
    """
    
    def __init__(self):
        """Initialize the hybrid extractor with rule-based and LLM components."""
        self.rule_extractor = RuleBasedExtractor()
        self.llm_client = OllamaClient()
        self.size_converter = SizeConverter()
        
        # Configure confidence thresholds
        self.high_confidence_threshold = 0.8
        self.low_confidence_threshold = 0.4
    
    async def extract(self, email_data: Dict[str, Any], recent_orders: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
        """
        Extract order information using a hybrid approach.
        
        Args:
            email_data: Dictionary with email information
            recent_orders: Optional list of recent orders for linking
            
        Returns:
            Dictionary with extracted order information
        """
        try:
            if "plain_text" not in email_data:
                logger.error("Email data missing plain_text field")
                return {"error": "Missing plain_text in email data"}
            
            # First, try rule-based extraction
            email_text = email_data["plain_text"]
            rule_based_results = self.rule_extractor.extract_order_info(email_text)
            
            # Check if rule-based extraction is sufficient
            if self._is_high_confidence(rule_based_results):
                logger.info("High confidence rule-based extraction successful")
                
                # Normalize size
                if rule_based_results.get("product_size") and rule_based_results.get("product_name"):
                    size_info = self.size_converter.normalize_size(
                        rule_based_results["product_size"], 
                        rule_based_results["product_name"]
                    )
                    rule_based_results["product_size"] = size_info["us"] or rule_based_results["product_size"]
                    rule_based_results["converted_size_eu"] = size_info["eu"]
                
                # Add extraction method metadata
                rule_based_results["extraction_method"] = "rule_based"
                return rule_based_results
            
            # If rule-based extraction has low confidence, use LLM
            logger.info("Rule-based extraction has low confidence, falling back to LLM")
            
            # Prepare context for LLM
            context = {
                "recent_orders": recent_orders or []
            }
            
            # Call LLM for extraction
            llm_results = await self.llm_client.extract_order_info(email_text, context)
            
            # If LLM extraction failed completely, use rule-based results as fallback
            if not llm_results or "error" in llm_results:
                logger.warning("LLM extraction failed, using rule-based results as fallback")
                rule_based_results["extraction_method"] = "rule_based_fallback"
                return rule_based_results
            
            # Merge results, preferring high-confidence fields
            merged_results = self._merge_extraction_results(rule_based_results, llm_results)
            
            # Try to link orders if applicable
            if merged_results.get("platform") == "stockx" and recent_orders:
                linked_order = self._try_link_orders(merged_results, recent_orders)
                if linked_order:
                    merged_results["linked_order_id"] = linked_order.get("order_number")
            
            # Add extraction method metadata
            merged_results["extraction_method"] = "hybrid"
            
            return merged_results
            
        except Exception as e:
            logger.error(f"Error in hybrid extraction: {e}")
            return {
                "error": str(e),
                "extraction_method": "failed"
            }
    
    def _is_high_confidence(self, extraction_results: Dict[str, Any]) -> bool:
        """
        Check if the extraction results have high confidence.
        
        Args:
            extraction_results: The extraction results to check
            
        Returns:
            True if extraction has high confidence, False otherwise
        """
        if "confidence_scores" not in extraction_results:
            return False
        
        scores = extraction_results["confidence_scores"]
        
        # Check required fields
        required_fields = ["order_number", "product_name"]
        for field in required_fields:
            if field not in scores or scores[field] < self.high_confidence_threshold:
                return False
        
        # Check if we have at least the order number and product
        if not extraction_results.get("order_number") or not extraction_results.get("product_name"):
            return False
        
        return True
    
    def _merge_extraction_results(self, rule_results: Dict[str, Any], llm_results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Merge rule-based and LLM extraction results, prioritizing higher confidence.
        
        Args:
            rule_results: Rule-based extraction results
            llm_results: LLM extraction results
            
        Returns:
            Merged extraction results
        """
        merged = {}
        
        # Fields to compare and merge
        fields = [
            "platform", "order_number", "order_date", "product_name", 
            "product_size", "price", "tracking_number", "order_status", 
            "carrier", "customer_email"
        ]
        
        # Special fields to copy from LLM results
        llm_only_fields = ["converted_size_eu", "linked_order_id", "graphql_instruction"]
        
        # Get confidence scores
        rule_scores = rule_results.get("confidence_scores", {})
        llm_scores = llm_results.get("confidence_scores", {})
        
        # Merge regular fields based on confidence
        for field in fields:
            rule_value = rule_results.get(field)
            llm_value = llm_results.get(field)
            rule_confidence = rule_scores.get(field, 0.0)
            llm_confidence = llm_scores.get(field, 0.0)
            
            # Choose higher confidence value
            if rule_confidence > llm_confidence and rule_value is not None:
                merged[field] = rule_value
            elif llm_value is not None:
                merged[field] = llm_value
            elif rule_value is not None:
                merged[field] = rule_value
        
        # Copy LLM-specific fields
        for field in llm_only_fields:
            if field in llm_results and llm_results[field] is not None:
                merged[field] = llm_results[field]
        
        # Merge confidence scores
        merged_scores = {}
        for field in set(rule_scores.keys()) | set(llm_scores.keys()):
            merged_scores[field] = max(rule_scores.get(field, 0.0), llm_scores.get(field, 0.0))
        
        merged["confidence_scores"] = merged_scores
        
        return merged
    
    def _try_link_orders(self, stockx_order: Dict[str, Any], recent_orders: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """
        Try to link a StockX order with recent orders.
        
        Args:
            stockx_order: StockX order information
            recent_orders: List of recent orders
            
        Returns:
            Matching order or None
        """
        if not stockx_order.get("product_name") or not stockx_order.get("product_size"):
            return None
        
        # Filter for Shopify orders
        shopify_orders = [order for order in recent_orders if order.get("platform") == "shopify"]
        if not shopify_orders:
            return None
        
        stockx_product = stockx_order["product_name"].lower()
        stockx_size = stockx_order.get("product_size", "").lower()
        
        # Get order date if available
        stockx_date = None
        if stockx_order.get("order_date"):
            try:
                stockx_date = datetime.fromisoformat(stockx_order["order_date"].replace("Z", "+00:00"))
            except (ValueError, TypeError):
                pass
        
        best_match = None
        best_score = 0
        
        for order in shopify_orders:
            score = 0
            
            # Check product name similarity
            if order.get("product_name") and stockx_product:
                shopify_product = order["product_name"].lower()
                if stockx_product == shopify_product:
                    score += 3  # Exact match
                elif stockx_product in shopify_product or shopify_product in stockx_product:
                    score += 2  # Partial match
            
            # Check size match
            if order.get("product_size") and stockx_size:
                shopify_size = order["product_size"].lower()
                if stockx_size == shopify_size:
                    score += 3  # Exact match
            
            # Check date proximity
            if stockx_date and order.get("order_date"):
                try:
                    shopify_date = datetime.fromisoformat(order["order_date"].replace("Z", "+00:00"))
                    date_diff = abs((stockx_date - shopify_date).total_seconds())
                    if date_diff < 60 * 60 * 24 * 2:  # Within 48 hours
                        score += 2
                    elif date_diff < 60 * 60 * 24 * 7:  # Within a week
                        score += 1
                except (ValueError, TypeError):
                    pass
            
            # Update best match
            if score > best_score:
                best_score = score
                best_match = order
        
        # Return match only if it's reasonably confident
        if best_score >= 5:
            return best_match
        
        return None 