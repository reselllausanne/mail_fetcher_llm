# Setting Up Gmail API Credentials

This guide will walk you through the process of setting up Gmail API credentials for the Email Order System.

## Prerequisites

- A Google account
- Access to the [Google Cloud Console](https://console.cloud.google.com/)

## Step 1: Create a Google Cloud Project

1. Go to the [Google Cloud Console](https://console.cloud.google.com/).
2. Click on the project dropdown at the top of the page and then click "New Project".
3. Enter a project name (e.g., "Email Order System") and click "Create".
4. Wait for the project to be created, then select it from the project dropdown.

## Step 2: Enable the Gmail API

1. Navigate to the "APIs & Services > Library" section from the left sidebar.
2. Search for "Gmail API" and click on it in the results.
3. Click the "Enable" button.

## Step 3: Configure the OAuth Consent Screen

1. Go to "APIs & Services > OAuth consent screen" from the left sidebar.
2. Select "External" as the user type (or "Internal" if you're using Google Workspace) and click "Create".
3. Fill in the required fields:
   - App name: "Email Order System"
   - User support email: your email address
   - Developer contact information: your email address
4. Click "Save and Continue".
5. On the "Scopes" page, click "Add or Remove Scopes" and add the following scopes:
   - `https://www.googleapis.com/auth/gmail.readonly` (allows reading emails)
6. Click "Save and Continue".
7. Add test users (including your own email address) and click "Save and Continue".
8. Review your app configuration and click "Back to Dashboard".

## Step 4: Create OAuth 2.0 Credentials

1. Go to "APIs & Services > Credentials" from the left sidebar.
2. Click "Create Credentials" and select "OAuth client ID".
3. Choose "Desktop app" as the application type.
4. Enter a name for the OAuth client (e.g., "Email Order System Client").
5. Click "Create".
6. You'll see a modal with your client ID and client secret. Click "OK" to close it.
7. You can always download the credentials by clicking the download icon next to your OAuth client ID.

## Step 5: Get a Refresh Token

To use the Gmail API with our system, you'll need to get a refresh token. Follow these steps:

1. Install the Google OAuth library:
   ```bash
   pip install google-auth google-auth-oauthlib google-auth-httplib2 google-api-python-client
   ```

2. Create a file named `get_refresh_token.py` with the following content:
   ```python
   import os
   import pickle
   from google_auth_oauthlib.flow import InstalledAppFlow
   from google.auth.transport.requests import Request
   
   # If modifying these scopes, delete the file token.pickle.
   SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']
   
   def get_refresh_token():
       creds = None
       
       # The file token.pickle stores the user's access and refresh tokens
       if os.path.exists('token.pickle'):
           with open('token.pickle', 'rb') as token:
               creds = pickle.load(token)
       
       # If there are no valid credentials available, let the user log in.
       if not creds or not creds.valid:
           if creds and creds.expired and creds.refresh_token:
               creds.refresh(Request())
           else:
               flow = InstalledAppFlow.from_client_secrets_file(
                   'credentials.json', SCOPES)
               creds = flow.run_local_server(port=0)
           
           # Save the credentials for the next run
           with open('token.pickle', 'wb') as token:
               pickle.dump(creds, token)
       
       print("Refresh Token:", creds.refresh_token)
   
   if __name__ == '__main__':
       get_refresh_token()
   ```

3. Download your OAuth credentials JSON file from the Google Cloud Console and save it as `credentials.json` in the same directory as the script.

4. Run the script:
   ```bash
   python get_refresh_token.py
   ```

5. A browser window will open asking you to authorize the application. Sign in with your Google account and grant the requested permissions.

6. After authorization, the script will display your refresh token in the terminal. This token doesn't expire until you revoke access.

## Step 6: Update Environment Variables

Update your `.env` file with the Gmail API credentials:

```
GMAIL_CLIENT_ID=your_client_id_from_google_cloud
GMAIL_CLIENT_SECRET=your_client_secret_from_google_cloud
GMAIL_REFRESH_TOKEN=your_refresh_token_from_the_script
```

## Troubleshooting

### Access Issues

- If you're getting "Access Denied" errors, make sure:
  - The Gmail API is enabled in your Google Cloud project
  - Your OAuth consent screen is properly configured
  - You've added yourself as a test user if you're using an external user type
  - The correct scopes are enabled

### Token Expiration

- Refresh tokens don't expire unless you revoke access or change security settings in your Google account
- If you need a new refresh token, delete the `token.pickle` file and run the script again

### API Limitations

- The Gmail API has usage limits. If you're processing a large number of emails, you might hit these limits
- In a production environment, consider using service account authentication for higher quotas

## Next Steps

Once you have your Gmail API credentials set up, you're ready to use the Email Order System. The system will use these credentials to authenticate with Gmail and fetch order confirmation emails for processing.

For more information on the Gmail API, visit the [official documentation](https://developers.google.com/gmail/api). 