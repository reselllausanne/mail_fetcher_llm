# Email Order System API Usage Guide

This guide provides detailed instructions for authenticating with and using the Email Order System API.

## Authentication

The API uses JWT (JSON Web Token) authentication. To access protected endpoints, you'll need to obtain an access token.

### Getting an Access Token

```bash
# Request an access token
curl -X POST "http://localhost:8000/auth/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin&password=admin123"
```

Example response:
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer"
}
```

The system has two demo users:
- `admin`: password `admin123` (has access to all endpoints)
- `user`: password `user123` (has access to emails and orders endpoints only)

### Using the Access Token

Include the token in the Authorization header for all protected API requests:

```bash
curl -X GET "http://localhost:8000/api/emails" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

## Email Endpoints

### List Processed Emails

```bash
# Get a list of all processed emails
curl -X GET "http://localhost:8000/api/emails" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

### Fetch Emails from Gmail

```bash
# Fetch new emails from Gmail
curl -X POST "http://localhost:8000/api/emails/fetch" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "days": 7,
    "limit": 50,
    "query": "subject:StockX OR subject:Shopify"
  }'
```

### Get a Specific Email

```bash
# Get details for a specific email by ID
curl -X GET "http://localhost:8000/api/emails/{email_id}" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

### Process an Email

```bash
# Process a specific email to extract order info
curl -X POST "http://localhost:8000/api/emails/{email_id}/process" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

## Order Endpoints

### List Orders

```bash
# Get a list of all extracted orders
curl -X GET "http://localhost:8000/api/orders" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

### Get a Specific Order

```bash
# Get details for a specific order by ID
curl -X GET "http://localhost:8000/api/orders/{order_id}" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

### List Products in an Order

```bash
# Get all products in a specific order
curl -X GET "http://localhost:8000/api/orders/{order_id}/products" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

## Shopify Integration

### Fetch Orders from Shopify

```bash
# Fetch orders from Shopify
curl -X POST "http://localhost:8000/api/shopify/orders/sync" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "limit": 10
  }'
```

### List Shopify Orders

```bash
# Get all Shopify orders
curl -X GET "http://localhost:8000/api/shopify/orders" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

## Using the API with Python

Here's a simple Python example to authenticate and fetch emails:

```python
import requests
import json

# API Base URL
BASE_URL = "http://localhost:8000"

# Get access token
auth_response = requests.post(
    f"{BASE_URL}/auth/token",
    data={
        "username": "admin",
        "password": "admin123"
    },
    headers={"Content-Type": "application/x-www-form-urlencoded"}
)

# Extract token
token_data = auth_response.json()
access_token = token_data["access_token"]

# Use the token to fetch emails
headers = {
    "Authorization": f"Bearer {access_token}",
    "Content-Type": "application/json"
}

# Fetch emails from Gmail
fetch_response = requests.post(
    f"{BASE_URL}/api/emails/fetch",
    headers=headers,
    json={
        "days": 7,
        "limit": 10,
        "query": "subject:StockX OR subject:Shopify"
    }
)

# Print the response
print(json.dumps(fetch_response.json(), indent=2))

# List processed emails
emails_response = requests.get(
    f"{BASE_URL}/api/emails",
    headers=headers
)

# Print the response
print(json.dumps(emails_response.json(), indent=2))
```

## Error Handling

The API returns standard HTTP status codes:

- 200: Success
- 400: Bad Request
- 401: Unauthorized (invalid or missing token)
- 403: Forbidden (insufficient permissions)
- 404: Not Found
- 422: Validation Error (invalid request data)
- 500: Internal Server Error

Error responses include a JSON body with details:

```json
{
  "detail": "Error message explaining what went wrong"
}
```

## Rate Limiting

The API includes rate limiting to prevent abuse. If you exceed the rate limit, you'll receive a 429 Too Many Requests response.

## Environment Variables

The API requires several environment variables to be set for proper functioning. Refer to the `.env.example` file in the root directory for the required variables. 