# Setting Up Shopify API Credentials

This guide will walk you through the process of setting up Shopify API credentials for the Email Order System.

## Prerequisites

- A Shopify store (development store or paid plan)
- Admin access to your Shopify store

## Step 1: Create a Custom App in Shopify

1. Log in to your Shopify admin panel at `https://your-store-name.myshopify.com/admin`.
2. Navigate to "Apps" from the left sidebar.
3. Click on "Develop apps" at the top-right corner.
4. Click "Create an app" button.
5. Enter a name for your app (e.g., "Email Order System").
6. Under "App developer", enter your email address.
7. Click "Create app".

## Step 2: Configure API Scopes

After creating the app, you'll need to configure the required API access scopes:

1. In your app's configuration page, click on "Configuration".
2. Scroll down to the "Admin API integration" section.
3. Click "Configure" next to Admin API Access.
4. Under "Admin API access scopes", select the following scopes:
   - `read_orders`: To read order information
   - `read_customers`: To read customer information
   - `read_products`: To read product information
5. Click "Save" to apply these permissions.

## Step 3: Create API Credentials

Now, you'll create the API credentials that the Email Order System will use:

1. Go to the "API credentials" tab.
2. Click "Install app" to generate the credentials.
3. You'll see a modal asking for confirmation. Click "Install".
4. After installation, you'll be provided with an API access token.
5. **Important**: Copy and save this access token immediately. For security reasons, Shopify will only show this token once.

## Step 4: Get Your Shopify Store URL

You'll need your Shopify store URL in the following format:

```
your-store-name.myshopify.com
```

Replace `your-store-name` with your actual Shopify store name.

## Step 5: Update Environment Variables

Update your `.env` file with the Shopify API credentials:

```
SHOPIFY_STORE_URL=your-store-name.myshopify.com
SHOPIFY_ACCESS_TOKEN=your_access_token_from_step_3
```

## Testing the Connection

To verify that your Shopify API credentials are working correctly, you can run this simple Python script:

```python
import requests
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Get credentials from environment variables
store_url = os.getenv("SHOPIFY_STORE_URL")
access_token = os.getenv("SHOPIFY_ACCESS_TOKEN")

# Construct the GraphQL endpoint URL
graphql_url = f"https://{store_url}/admin/api/2023-10/graphql.json"

# Set up the headers with the access token
headers = {
    "Content-Type": "application/json",
    "X-Shopify-Access-Token": access_token
}

# Simple GraphQL query to test the connection
query = """
{
  shop {
    name
    email
    myshopifyDomain
  }
}
"""

# Make the request
response = requests.post(
    graphql_url,
    json={"query": query},
    headers=headers
)

# Print the response
print("Status Code:", response.status_code)
print("Response:")
print(response.json())
```

If everything is set up correctly, you should see your shop details in the response.

## Shopify GraphQL API Overview

The Email Order System uses Shopify's GraphQL Admin API to fetch order information. Here's a brief overview of the key GraphQL queries used:

### Fetching Orders

```graphql
{
  orders(first: 10) {
    edges {
      node {
        id
        name
        createdAt
        customer {
          email
          firstName
          lastName
        }
        lineItems(first: 10) {
          edges {
            node {
              title
              quantity
              variant {
                sku
                price
              }
            }
          }
        }
      }
    }
  }
}
```

### Fetching a Specific Order

```graphql
{
  order(id: "gid://shopify/Order/1234567890") {
    id
    name
    createdAt
    customer {
      email
      firstName
      lastName
    }
    lineItems(first: 10) {
      edges {
        node {
          title
          quantity
          variant {
            sku
            price
          }
        }
      }
    }
  }
}
```

## Troubleshooting

### API Access Issues

- If you receive `401 Unauthorized` errors, verify your access token is correct
- If you receive `403 Forbidden` errors, check that you've enabled the necessary API scopes
- Make sure your app is still installed in your Shopify store

### API Rate Limits

Shopify imposes rate limits on API requests:

- GraphQL Admin API: 1,000 requests per minute
- REST Admin API: Varies based on your store plan

If you hit rate limits, implement retry logic with exponential backoff in your application.

### Access Token Security

- Your access token provides complete access to your store's data through the API
- Keep your token secure and never expose it in client-side code
- Regenerate your token if you suspect it has been compromised

## Additional Resources

- [Shopify Admin API Documentation](https://shopify.dev/docs/api/admin)
- [Shopify GraphQL Admin API Reference](https://shopify.dev/docs/api/admin-graphql)
- [Shopify API Versioning Guide](https://shopify.dev/docs/api/usage/versioning)

## Next Steps

With your Shopify API credentials set up, the Email Order System can now fetch order information from your Shopify store and correlate it with orders extracted from emails. This enables a comprehensive view of your order data across platforms. 