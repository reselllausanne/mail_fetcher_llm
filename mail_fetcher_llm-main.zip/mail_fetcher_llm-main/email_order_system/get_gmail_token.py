#!/usr/bin/env python
import os
from google_auth_oauthlib.flow import InstalledAppFlow
from dotenv import load_dotenv
import json

# Load environment variables
load_dotenv()

# Set up the scopes
SCOPES = ['https://mail.google.com/']

def get_refresh_token():
    """Gets refresh token from Gmail API."""
    
    # Get client ID and secret from environment
    client_id = os.getenv("GMAIL_CLIENT_ID")
    client_secret = os.getenv("GMAIL_CLIENT_SECRET")
    
    if not client_id or not client_secret:
        print("Error: GMAIL_CLIENT_ID and GMAIL_CLIENT_SECRET must be set in .env file")
        return
    
    # Create client config
    client_config = {
        "installed": {
            "client_id": client_id,
            "client_secret": client_secret,
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "redirect_uris": ["urn:ietf:wg:oauth:2.0:oob", "http://localhost"]
        }
    }
    
    # Create the flow
    flow = InstalledAppFlow.from_client_config(
        client_config,
        SCOPES,
        redirect_uri='http://localhost:8080'
    )
    
    # Run the OAuth flow
    credentials = flow.run_local_server(port=8080)
    
    # Print the refresh token
    print("\nRefresh Token:", credentials.refresh_token)
    print("\nAdd this to your .env file as GMAIL_REFRESH_TOKEN")
    
    # Also save to a file
    with open('gmail_refresh_token.txt', 'w') as f:
        f.write(credentials.refresh_token)
    
    return credentials.refresh_token

if __name__ == "__main__":
    get_refresh_token() 